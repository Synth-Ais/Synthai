import { Link } from './link'

export * from './link'

export default Link
