/* eslint-disable import/prefer-default-export */
// BlockNote uses a similar pattern as Tiptap, so for now we can just export that
export { EditorContent } from '@tiptap/react'
