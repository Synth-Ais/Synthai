export type SuggestionItem = {
  name: string
}
