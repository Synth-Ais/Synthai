import { CodeBlockLowlight } from './code-block-lowlight'

export * from './code-block-lowlight'

export default CodeBlockLowlight
