export interface SearchProps {
  searchMode: 'vector' | 'hybrid'
  vectorWeight: number
}
