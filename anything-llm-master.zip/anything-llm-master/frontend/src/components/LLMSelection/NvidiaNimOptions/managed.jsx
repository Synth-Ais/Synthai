/**
 * This component is used to select, start, and manage NVIDIA NIM
 * containers and images via docker management tools.
 */
export default function ManagedNvidiaNimOptions({ settings }) {
  return null;
}
