import { VM } from 'vm2';
import { promises as fs } from 'fs';
import { join } from 'path';
import { tmpdir } from 'os';
import { randomUUID } from 'crypto';

export interface SandboxResult {
  success: boolean;
  output: string;
  error?: string;
  executionTime: number;
  memoryUsage: number;
}

export interface SandboxTest {
  name: string;
  code: string;
  timeout: number;
  expectedOutput?: string;
}

export class SandboxRunner {
  private readonly defaultTimeout = 5000; // 5 seconds
  private readonly maxMemory = 128 * 1024 * 1024; // 128MB

  async runJavaScript(code: string, timeout: number = this.defaultTimeout): Promise<SandboxResult> {
    const startTime = Date.now();
    const startMemory = process.memoryUsage().heapUsed;

    try {
      const vm = new VM({
        timeout,
        sandbox: {
          console: {
            log: (...args: any[]) => this.captureOutput(args),
            error: (...args: any[]) => this.captureError(args),
            warn: (...args: any[]) => this.captureOutput(args),
          },
          setTimeout: undefined, // Disable timers for security
          setInterval: undefined,
          setImmediate: undefined,
          require: undefined, // Disable require for security
          process: undefined,
          global: undefined,
          Buffer: undefined,
        },
        wasm: false,
        fixAsync: true,
      });

      let output = '';
      let errorOutput = '';

      // Capture console output
      const originalLog = console.log;
      const originalError = console.error;

      const outputCapture: string[] = [];
      const errorCapture: string[] = [];

      vm.sandbox.console = {
        log: (...args: any[]) => {
          outputCapture.push(args.map(arg => String(arg)).join(' '));
        },
        error: (...args: any[]) => {
          errorCapture.push(args.map(arg => String(arg)).join(' '));
        },
        warn: (...args: any[]) => {
          outputCapture.push('[WARN] ' + args.map(arg => String(arg)).join(' '));
        }
      };

      const result = vm.run(code);
      
      output = outputCapture.join('\n');
      if (result !== undefined) {
        output += (output ? '\n' : '') + String(result);
      }

      const executionTime = Date.now() - startTime;
      const endMemory = process.memoryUsage().heapUsed;
      const memoryUsage = endMemory - startMemory;

      return {
        success: true,
        output: output || 'Code executed successfully (no output)',
        executionTime,
        memoryUsage: Math.max(0, memoryUsage),
        error: errorCapture.length > 0 ? errorCapture.join('\n') : undefined
      };

    } catch (error) {
      const executionTime = Date.now() - startTime;
      const endMemory = process.memoryUsage().heapUsed;
      const memoryUsage = Math.max(0, endMemory - startMemory);

      return {
        success: false,
        output: '',
        error: error instanceof Error ? error.message : String(error),
        executionTime,
        memoryUsage
      };
    }
  }

  async runTests(tests: SandboxTest[]): Promise<Array<SandboxResult & { testName: string }>> {
    const results = [];

    for (const test of tests) {
      const result = await this.runJavaScript(test.code, test.timeout);
      results.push({
        ...result,
        testName: test.name
      });
    }

    return results;
  }

  async testCodeIntegration(
    baseCode: string,
    newCode: string,
    integrationTests: string[]
  ): Promise<{ 
    baseResult: SandboxResult; 
    integratedResult: SandboxResult; 
    testResults: SandboxResult[];
    isCompatible: boolean;
  }> {
    // Test base code
    const baseResult = await this.runJavaScript(baseCode);
    
    // Test integrated code
    const integratedCode = baseCode + '\n\n' + newCode;
    const integratedResult = await this.runJavaScript(integratedCode);
    
    // Run integration tests
    const testResults = [];
    for (const test of integrationTests) {
      const testCode = integratedCode + '\n\n' + test;
      const testResult = await this.runJavaScript(testCode);
      testResults.push(testResult);
    }

    // Determine compatibility
    const isCompatible = 
      baseResult.success && 
      integratedResult.success && 
      testResults.every(result => result.success) &&
      !integratedResult.error;

    return {
      baseResult,
      integratedResult,
      testResults,
      isCompatible
    };
  }

  private captureOutput(args: any[]): string {
    return args.map(arg => {
      if (typeof arg === 'object') {
        try {
          return JSON.stringify(arg, null, 2);
        } catch {
          return String(arg);
        }
      }
      return String(arg);
    }).join(' ');
  }

  private captureError(args: any[]): string {
    return '[ERROR] ' + this.captureOutput(args);
  }

  generateCompatibilityTests(functions: Array<{ name: string; params: string[] }>): string[] {
    return functions.map(func => {
      const paramList = func.params.map((_, i) => `param${i}`).join(', ');
      const testParams = func.params.map((_, i) => {
        return i === 0 ? '"test"' : i === 1 ? '123' : 'true';
      }).join(', ');

      return `
        // Test ${func.name} function
        try {
          if (typeof ${func.name} === 'function') {
            console.log('Function ${func.name} is available');
            const result = ${func.name}(${testParams});
            console.log('${func.name} executed successfully, result:', result);
          } else {
            console.error('Function ${func.name} is not available');
          }
        } catch (error) {
          console.error('Error testing ${func.name}:', error.message);
        }
      `;
    });
  }
}

export const sandboxRunner = new SandboxRunner();
