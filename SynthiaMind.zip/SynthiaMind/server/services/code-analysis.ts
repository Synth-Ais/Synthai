import { parse } from "@babel/parser";
import traverse from "@babel/traverse";
import { openaiService, type CodeAnalysisResult } from "./openai-service";

export interface ASTFunction {
  name: string;
  params: string[];
  returnType?: string;
  complexity: number;
  dependencies: string[];
  startLine: number;
  endLine: number;
}

export interface ASTAnalysis {
  functions: ASTFunction[];
  imports: string[];
  exports: string[];
  classes: string[];
  variables: string[];
  complexity: number;
}

export class CodeAnalysisService {
  async analyzeJavaScriptFile(filename: string, content: string): Promise<ASTAnalysis> {
    try {
      // Determine if it's TypeScript
      const isTypeScript = filename.endsWith('.ts') || filename.endsWith('.tsx');
      
      const ast = parse(content, {
        sourceType: 'module',
        plugins: [
          'jsx',
          'typescript',
          'decorators-legacy',
          'classProperties',
          'asyncGenerators',
          'functionBind',
          'exportDefaultFrom',
          'exportNamespaceFrom',
          'dynamicImport',
          'nullishCoalescingOperator',
          'optionalChaining'
        ]
      });

      const analysis: ASTAnalysis = {
        functions: [],
        imports: [],
        exports: [],
        classes: [],
        variables: [],
        complexity: 0
      };

      let totalComplexity = 0;

      traverse(ast, {
        // Handle imports
        ImportDeclaration(path) {
          const source = path.node.source.value;
          analysis.imports.push(source);
        },

        // Handle exports
        ExportNamedDeclaration(path) {
          if (path.node.declaration) {
            if (path.node.declaration.type === 'FunctionDeclaration' && path.node.declaration.id) {
              analysis.exports.push(path.node.declaration.id.name);
            } else if (path.node.declaration.type === 'VariableDeclaration') {
              path.node.declaration.declarations.forEach(decl => {
                if (decl.id.type === 'Identifier') {
                  analysis.exports.push(decl.id.name);
                }
              });
            }
          }
        },

        ExportDefaultDeclaration(path) {
          analysis.exports.push('default');
        },

        // Handle functions
        FunctionDeclaration(path) {
          if (path.node.id) {
            const func = this.analyzeFunctionNode(path.node, path);
            analysis.functions.push(func);
            totalComplexity += func.complexity;
          }
        },

        FunctionExpression(path) {
          if (path.node.id) {
            const func = this.analyzeFunctionNode(path.node, path);
            analysis.functions.push(func);
            totalComplexity += func.complexity;
          }
        },

        ArrowFunctionExpression(path) {
          // Try to get function name from parent variable declaration
          let name = 'anonymous';
          if (path.parent.type === 'VariableDeclarator' && path.parent.id.type === 'Identifier') {
            name = path.parent.id.name;
          }
          
          const func: ASTFunction = {
            name,
            params: path.node.params.map(param => 
              param.type === 'Identifier' ? param.name : 'unknown'
            ),
            complexity: this.calculateComplexity(path),
            dependencies: [],
            startLine: path.node.loc?.start.line || 0,
            endLine: path.node.loc?.end.line || 0
          };
          
          analysis.functions.push(func);
          totalComplexity += func.complexity;
        },

        // Handle classes
        ClassDeclaration(path) {
          if (path.node.id) {
            analysis.classes.push(path.node.id.name);
          }
        },

        // Handle variables
        VariableDeclaration(path) {
          path.node.declarations.forEach(decl => {
            if (decl.id.type === 'Identifier') {
              analysis.variables.push(decl.id.name);
            }
          });
        }
      });

      analysis.complexity = totalComplexity;
      return analysis;
    } catch (error) {
      console.error(`Failed to analyze ${filename}:`, error);
      return {
        functions: [],
        imports: [],
        exports: [],
        classes: [],
        variables: [],
        complexity: 0
      };
    }
  }

  private analyzeFunctionNode(node: any, path: any): ASTFunction {
    const name = node.id?.name || 'anonymous';
    const params = node.params.map((param: any) => {
      if (param.type === 'Identifier') {
        return param.name;
      } else if (param.type === 'RestElement' && param.argument.type === 'Identifier') {
        return `...${param.argument.name}`;
      }
      return 'unknown';
    });

    return {
      name,
      params,
      returnType: this.extractReturnType(node),
      complexity: this.calculateComplexity(path),
      dependencies: this.extractDependencies(path),
      startLine: node.loc?.start.line || 0,
      endLine: node.loc?.end.line || 0
    };
  }

  private extractReturnType(node: any): string | undefined {
    if (node.returnType?.typeAnnotation) {
      // Basic TypeScript return type extraction
      const type = node.returnType.typeAnnotation;
      if (type.type === 'TSStringKeyword') return 'string';
      if (type.type === 'TSNumberKeyword') return 'number';
      if (type.type === 'TSBooleanKeyword') return 'boolean';
      if (type.type === 'TSVoidKeyword') return 'void';
      if (type.type === 'TSAnyKeyword') return 'any';
    }
    return undefined;
  }

  private calculateComplexity(path: any): number {
    let complexity = 1; // Base complexity

    path.traverse({
      IfStatement() { complexity++; },
      SwitchCase() { complexity++; },
      ForStatement() { complexity++; },
      ForInStatement() { complexity++; },
      ForOfStatement() { complexity++; },
      WhileStatement() { complexity++; },
      DoWhileStatement() { complexity++; },
      ConditionalExpression() { complexity++; },
      LogicalExpression(innerPath: any) {
        if (innerPath.node.operator === '&&' || innerPath.node.operator === '||') {
          complexity++;
        }
      },
      CatchClause() { complexity++; }
    });

    return complexity;
  }

  private extractDependencies(path: any): string[] {
    const dependencies: Set<string> = new Set();

    path.traverse({
      CallExpression(innerPath: any) {
        if (innerPath.node.callee.type === 'Identifier') {
          dependencies.add(innerPath.node.callee.name);
        } else if (innerPath.node.callee.type === 'MemberExpression' && 
                   innerPath.node.callee.object.type === 'Identifier') {
          dependencies.add(innerPath.node.callee.object.name);
        }
      },
      Identifier(innerPath: any) {
        // Only add if it's not a declaration
        if (!innerPath.isBindingIdentifier()) {
          dependencies.add(innerPath.node.name);
        }
      }
    });

    return Array.from(dependencies);
  }

  async analyzeFileWithAI(filename: string, content: string, existingFiles: Record<string, string>): Promise<CodeAnalysisResult> {
    try {
      return await openaiService.analyzeCode(content, filename, JSON.stringify(Object.keys(existingFiles)));
    } catch (error) {
      // Return fallback analysis if OpenAI is not available
      return {
        safetyScore: 70,
        compatibilityScore: 80,
        complexity: 5,
        recommendations: ["Enable OpenAI integration for detailed analysis"],
        suggestedChanges: [],
        riskAssessment: { level: 'medium', concerns: ["No AI analysis available"] }
      };
    }
  }

  getFileType(filename: string): string {
    const ext = filename.split('.').pop()?.toLowerCase();
    switch (ext) {
      case 'js': return 'javascript';
      case 'jsx': return 'jsx';
      case 'ts': return 'typescript';
      case 'tsx': return 'tsx';
      case 'py': return 'python';
      case 'html': return 'html';
      case 'css': return 'css';
      case 'scss': case 'sass': return 'scss';
      case 'json': return 'json';
      case 'md': return 'markdown';
      default: return 'text';
    }
  }

  isAnalyzableFile(filename: string): boolean {
    const analyzableExtensions = ['js', 'jsx', 'ts', 'tsx', 'py', 'html', 'css', 'scss', 'sass', 'json'];
    const ext = filename.split('.').pop()?.toLowerCase();
    return analyzableExtensions.includes(ext || '');
  }
}

export const codeAnalysisService = new CodeAnalysisService();
