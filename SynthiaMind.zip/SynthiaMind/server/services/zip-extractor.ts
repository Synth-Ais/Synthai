import JSZip from "jszip";

export interface ExtractedFile {
  path: string;
  content: string;
  size: number;
  isDirectory: boolean;
}

export interface ExtractionResult {
  files: Record<string, string>;
  structure: ExtractedFile[];
  totalFiles: number;
  totalSize: number;
}

export class ZipExtractor {
  async extractZip(zipData: Buffer): Promise<ExtractionResult> {
    try {
      const zip = new JSZip();
      const zipContent = await zip.loadAsync(zipData);
      
      const files: Record<string, string> = {};
      const structure: ExtractedFile[] = [];
      let totalSize = 0;

      // Process all files in the ZIP
      for (const [relativePath, zipEntry] of Object.entries(zipContent.files)) {
        if (zipEntry.dir) {
          // Directory entry
          structure.push({
            path: relativePath,
            content: '',
            size: 0,
            isDirectory: true
          });
        } else {
          // File entry
          try {
            const content = await zipEntry.async('text');
            const size = content.length;
            
            files[relativePath] = content;
            structure.push({
              path: relativePath,
              content,
              size,
              isDirectory: false
            });
            
            totalSize += size;
          } catch (error) {
            console.warn(`Failed to extract file ${relativePath}:`, error);
            // Skip binary files or files that can't be read as text
          }
        }
      }

      return {
        files,
        structure,
        totalFiles: Object.keys(files).length,
        totalSize
      };
    } catch (error) {
      console.error('ZIP extraction failed:', error);
      throw new Error(`Failed to extract ZIP file: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  getFileExtension(filename: string): string {
    const lastDot = filename.lastIndexOf('.');
    return lastDot !== -1 ? filename.substring(lastDot + 1).toLowerCase() : '';
  }

  isCodeFile(filename: string): boolean {
    const codeExtensions = [
      'js', 'jsx', 'ts', 'tsx', 'py', 'java', 'c', 'cpp', 'cs', 'php', 'rb', 'go', 'rs', 'swift',
      'html', 'css', 'scss', 'sass', 'less', 'vue', 'svelte', 'json', 'yaml', 'yml', 'xml', 'sql'
    ];
    const extension = this.getFileExtension(filename);
    return codeExtensions.includes(extension);
  }

  filterCodeFiles(files: Record<string, string>): Record<string, string> {
    const codeFiles: Record<string, string> = {};
    
    for (const [path, content] of Object.entries(files)) {
      if (this.isCodeFile(path)) {
        codeFiles[path] = content;
      }
    }
    
    return codeFiles;
  }

  buildDirectoryTree(structure: ExtractedFile[]): any {
    const tree: any = {};
    
    structure.forEach(file => {
      const parts = file.path.split('/').filter(part => part.length > 0);
      let current = tree;
      
      parts.forEach((part, index) => {
        if (!current[part]) {
          current[part] = {
            type: index === parts.length - 1 && !file.isDirectory ? 'file' : 'directory',
            path: file.path,
            size: file.size,
            children: {}
          };
        }
        current = current[part].children;
      });
    });
    
    return tree;
  }
}

export const zipExtractor = new ZipExtractor();
