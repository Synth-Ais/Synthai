import OpenAI from "openai";

/*
The newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
*/

const openai = process.env.OPENAI_API_KEY ? new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY 
}) : null;

export interface CodeAnalysisResult {
  safetyScore: number;
  compatibilityScore: number;
  complexity: number;
  recommendations: string[];
  suggestedChanges: Array<{
    file: string;
    type: 'add' | 'modify' | 'delete';
    content: string;
    reason: string;
  }>;
  riskAssessment: {
    level: 'low' | 'medium' | 'high';
    concerns: string[];
  };
}

export interface NaturalLanguageInstruction {
  instruction: string;
  codebaseContext?: string;
  fileList?: string[];
}

export interface ProcessedInstruction {
  intent: string;
  actionPlan: Array<{
    step: number;
    action: string;
    targetFiles: string[];
    implementation: string;
  }>;
  estimatedComplexity: number;
  requiredCapabilities: string[];
  safetyChecks: string[];
}

export class OpenAIService {
  private async ensureApiKey() {
    if (!process.env.OPENAI_API_KEY || !openai) {
      throw new Error("OpenAI API key not found. Please set OPENAI_API_KEY environment variable.");
    }
  }

  async analyzeCode(codeContent: string, fileName: string, context?: string): Promise<CodeAnalysisResult> {
    await this.ensureApiKey();

    const prompt = `Analyze the following code for safety, compatibility, and quality:

File: ${fileName}
${context ? `Context: ${context}` : ''}

Code:
\`\`\`
${codeContent}
\`\`\`

Please provide analysis in JSON format with:
- safetyScore (0-100): How safe is this code?
- compatibilityScore (0-100): How compatible is it with existing systems?
- complexity (1-10): Code complexity level
- recommendations: Array of improvement suggestions
- suggestedChanges: Array of specific changes with file, type, content, reason
- riskAssessment: Object with level (low/medium/high) and concerns array

Focus on security vulnerabilities, performance issues, and integration compatibility.`;

    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: "You are an expert code analyst specializing in security, performance, and compatibility assessment. Respond only with valid JSON."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        response_format: { type: "json_object" },
        temperature: 0.3
      });

      const analysis = JSON.parse(response.choices[0].message.content || '{}');
      
      return {
        safetyScore: analysis.safetyScore || 0,
        compatibilityScore: analysis.compatibilityScore || 0,
        complexity: analysis.complexity || 1,
        recommendations: analysis.recommendations || [],
        suggestedChanges: analysis.suggestedChanges || [],
        riskAssessment: analysis.riskAssessment || { level: 'medium', concerns: [] }
      };
    } catch (error) {
      console.error('OpenAI analysis error:', error);
      throw new Error('Failed to analyze code with AI');
    }
  }

  async processNaturalLanguageInstruction(instruction: NaturalLanguageInstruction): Promise<ProcessedInstruction> {
    await this.ensureApiKey();

    const prompt = `Process this natural language instruction for a self-building code system:

Instruction: "${instruction.instruction}"
${instruction.codebaseContext ? `Codebase Context: ${instruction.codebaseContext}` : ''}
${instruction.fileList ? `Available Files: ${instruction.fileList.join(', ')}` : ''}

Analyze the intent and create a detailed action plan. Respond in JSON format with:
- intent: Clear statement of what the user wants
- actionPlan: Array of steps with step number, action description, targetFiles array, and implementation details
- estimatedComplexity: Scale 1-10 for implementation difficulty
- requiredCapabilities: Array of features/tools needed
- safetyChecks: Array of safety validations required

Examples of instructions:
- "Add error handling to all API calls" → Identify API calls, add try-catch blocks
- "Make the design more responsive" → Update CSS, add media queries
- "Add authentication" → Create auth system, protect routes
- "Fix security issues" → Scan for vulnerabilities, implement fixes

Be specific about file modifications and implementation steps.`;

    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: "You are an expert software architect who translates natural language instructions into detailed technical implementation plans. Always respond with valid JSON."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        response_format: { type: "json_object" },
        temperature: 0.4
      });

      const processed = JSON.parse(response.choices[0].message.content || '{}');
      
      return {
        intent: processed.intent || "Unknown intent",
        actionPlan: processed.actionPlan || [],
        estimatedComplexity: processed.estimatedComplexity || 5,
        requiredCapabilities: processed.requiredCapabilities || [],
        safetyChecks: processed.safetyChecks || []
      };
    } catch (error) {
      console.error('OpenAI instruction processing error:', error);
      throw new Error('Failed to process natural language instruction');
    }
  }

  async generateCodeSuggestion(
    context: string, 
    requirement: string, 
    existingCode?: string
  ): Promise<{ code: string; explanation: string; }> {
    await this.ensureApiKey();

    const prompt = `Generate code based on this requirement:

Context: ${context}
Requirement: ${requirement}
${existingCode ? `Existing Code:\n\`\`\`\n${existingCode}\n\`\`\`` : ''}

Provide a JSON response with:
- code: The generated/modified code
- explanation: Clear explanation of what the code does and why it's implemented this way

Focus on:
1. Clean, readable code following best practices
2. Error handling and edge cases
3. Security considerations
4. Performance optimization
5. Maintainability`;

    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: "You are an expert software developer who writes clean, secure, and efficient code. Always respond with valid JSON containing code and explanation."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        response_format: { type: "json_object" },
        temperature: 0.2
      });

      const result = JSON.parse(response.choices[0].message.content || '{}');
      
      return {
        code: result.code || "",
        explanation: result.explanation || "No explanation provided"
      };
    } catch (error) {
      console.error('OpenAI code generation error:', error);
      throw new Error('Failed to generate code suggestion');
    }
  }

  async evaluateIntegrationSafety(
    targetCodebase: string, 
    newCode: string, 
    integrationPlan: string
  ): Promise<{
    safetyScore: number;
    canProceed: boolean;
    warnings: string[];
    requiredChanges: string[];
  }> {
    await this.ensureApiKey();

    const prompt = `Evaluate the safety of integrating new code into an existing codebase:

Target Codebase Structure:
${targetCodebase}

New Code to Integrate:
\`\`\`
${newCode}
\`\`\`

Integration Plan:
${integrationPlan}

Analyze and respond in JSON format with:
- safetyScore: Number 0-100 indicating safety level
- canProceed: Boolean indicating if integration is safe
- warnings: Array of potential issues or concerns
- requiredChanges: Array of changes needed before safe integration

Consider:
1. Breaking changes to existing functionality
2. Security vulnerabilities
3. Performance impacts
4. Dependency conflicts
5. Data integrity risks
6. Backwards compatibility`;

    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: "You are a software security expert specializing in safe code integration. Prioritize security and stability. Always respond with valid JSON."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        response_format: { type: "json_object" },
        temperature: 0.1
      });

      const evaluation = JSON.parse(response.choices[0].message.content || '{}');
      
      return {
        safetyScore: evaluation.safetyScore || 0,
        canProceed: evaluation.canProceed || false,
        warnings: evaluation.warnings || [],
        requiredChanges: evaluation.requiredChanges || []
      };
    } catch (error) {
      console.error('OpenAI safety evaluation error:', error);
      throw new Error('Failed to evaluate integration safety');
    }
  }
}

export const openaiService = new OpenAIService();