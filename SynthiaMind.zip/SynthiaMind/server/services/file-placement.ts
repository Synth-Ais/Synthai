import { promises as fs } from 'fs';
import { join, extname, dirname } from 'path';

export interface FilePlacementSuggestion {
  fileName: string;
  suggestedPath: string;
  reason: string;
  confidence: number; // 0-100
  conflictRisk: 'low' | 'medium' | 'high';
  alternatives: string[];
}

export interface ProjectStructure {
  directories: string[];
  files: string[];
  frameworks: string[];
  hasTests: boolean;
  hasComponents: boolean;
  isTypeScript: boolean;
}

export class FilePlacementService {
  async analyzeProjectStructure(): Promise<ProjectStructure> {
    const structure: ProjectStructure = {
      directories: [],
      files: [],
      frameworks: [],
      hasTests: false,
      hasComponents: false,
      isTypeScript: false
    };

    try {
      // Scan current project structure
      const rootFiles = await this.scanDirectory('.');
      structure.files = rootFiles.files;
      structure.directories = rootFiles.directories;

      // Detect frameworks and patterns
      if (structure.files.includes('package.json')) {
        const packageJson = await this.readPackageJson();
        structure.frameworks = this.detectFrameworks(packageJson);
      }

      structure.hasTests = structure.directories.some(dir => 
        dir.includes('test') || dir.includes('spec') || dir.includes('__tests__')
      );
      
      structure.hasComponents = structure.directories.some(dir => 
        dir.includes('components') || dir.includes('component')
      );
      
      structure.isTypeScript = structure.files.some(file => 
        file.endsWith('.ts') || file.endsWith('.tsx')
      );

    } catch (error) {
      console.log('Using default project structure assumptions');
      // Default assumptions for web projects
      structure.directories = ['src', 'components', 'lib', 'utils'];
      structure.isTypeScript = true;
    }

    return structure;
  }

  async suggestFilePlacement(
    fileName: string, 
    fileContent: string, 
    extractedFiles: Record<string, string>
  ): Promise<FilePlacementSuggestion> {
    const projectStructure = await this.analyzeProjectStructure();
    const fileExt = extname(fileName);
    const fileBase = fileName.replace(fileExt, '');
    
    // Analyze file content to understand its purpose
    const fileAnalysis = this.analyzeFileContent(fileName, fileContent);
    
    let suggestedPath: string;
    let reason: string;
    let confidence: number;
    let alternatives: string[] = [];
    
    // Determine placement based on file type and content
    if (fileAnalysis.isComponent) {
      if (projectStructure.hasComponents) {
        suggestedPath = `src/components/${fileName}`;
        reason = "Contains React/UI component - placing in components directory";
        confidence = 90;
        alternatives = [`components/${fileName}`, `client/src/components/${fileName}`];
      } else {
        suggestedPath = `src/${fileName}`;
        reason = "Contains component but no components directory found";
        confidence = 70;
        alternatives = [`components/${fileName}`];
      }
    } else if (fileAnalysis.isUtility) {
      suggestedPath = `src/lib/${fileName}`;
      reason = "Contains utility functions - placing in lib directory";
      confidence = 85;
      alternatives = [`src/utils/${fileName}`, `lib/${fileName}`];
    } else if (fileAnalysis.isTest) {
      const testDir = projectStructure.hasTests ? this.findTestDirectory(projectStructure.directories) : '__tests__';
      suggestedPath = `${testDir}/${fileName}`;
      reason = "Contains test code - placing in test directory";
      confidence = 95;
      alternatives = [`tests/${fileName}`, `spec/${fileName}`];
    } else if (fileAnalysis.isConfig) {
      suggestedPath = fileName;
      reason = "Configuration file - placing in project root";
      confidence = 90;
      alternatives = [`config/${fileName}`];
    } else if (fileAnalysis.isStyle) {
      suggestedPath = `src/styles/${fileName}`;
      reason = "Stylesheet - placing in styles directory";
      confidence = 85;
      alternatives = [`styles/${fileName}`, `css/${fileName}`];
    } else if (fileAnalysis.isServer) {
      suggestedPath = `server/${fileName}`;
      reason = "Server-side code - placing in server directory";
      confidence = 90;
      alternatives = [`backend/${fileName}`, `api/${fileName}`];
    } else {
      // Default placement based on file extension
      const defaultPlacement = this.getDefaultPlacement(fileName, projectStructure);
      suggestedPath = defaultPlacement.path;
      reason = defaultPlacement.reason;
      confidence = defaultPlacement.confidence;
      alternatives = defaultPlacement.alternatives;
    }

    // Check for conflicts
    const conflictRisk = await this.assessConflictRisk(suggestedPath, fileContent, extractedFiles);

    return {
      fileName,
      suggestedPath,
      reason,
      confidence,
      conflictRisk,
      alternatives
    };
  }

  private analyzeFileContent(fileName: string, content: string) {
    const lowerContent = content.toLowerCase();
    const lowerFileName = fileName.toLowerCase();

    return {
      isComponent: (
        lowerContent.includes('export default function') ||
        lowerContent.includes('export function') ||
        lowerContent.includes('react') ||
        lowerContent.includes('jsx') ||
        lowerContent.includes('tsx') ||
        lowerFileName.includes('component')
      ),
      isUtility: (
        lowerContent.includes('export function') ||
        lowerContent.includes('export const') ||
        lowerContent.includes('utility') ||
        lowerContent.includes('helper') ||
        lowerFileName.includes('util') ||
        lowerFileName.includes('helper')
      ),
      isTest: (
        lowerContent.includes('test(') ||
        lowerContent.includes('it(') ||
        lowerContent.includes('describe(') ||
        lowerContent.includes('expect(') ||
        lowerFileName.includes('test') ||
        lowerFileName.includes('spec')
      ),
      isConfig: (
        lowerFileName.includes('config') ||
        lowerFileName.includes('.env') ||
        lowerFileName.includes('settings') ||
        fileName.endsWith('.json') ||
        fileName.endsWith('.yml') ||
        fileName.endsWith('.yaml')
      ),
      isStyle: (
        fileName.endsWith('.css') ||
        fileName.endsWith('.scss') ||
        fileName.endsWith('.sass') ||
        fileName.endsWith('.less')
      ),
      isServer: (
        lowerContent.includes('express') ||
        lowerContent.includes('server') ||
        lowerContent.includes('app.listen') ||
        lowerContent.includes('fastify') ||
        lowerFileName.includes('server') ||
        lowerFileName.includes('api')
      )
    };
  }

  private getDefaultPlacement(fileName: string, structure: ProjectStructure) {
    const ext = extname(fileName);
    
    switch (ext) {
      case '.js':
      case '.jsx':
        return {
          path: `src/${fileName}`,
          reason: "JavaScript file - placing in src directory",
          confidence: 75,
          alternatives: [`lib/${fileName}`, fileName]
        };
      case '.ts':
      case '.tsx':
        return {
          path: `src/${fileName}`,
          reason: "TypeScript file - placing in src directory", 
          confidence: 80,
          alternatives: [`lib/${fileName}`, fileName]
        };
      case '.py':
        return {
          path: fileName,
          reason: "Python file - placing in project root",
          confidence: 70,
          alternatives: [`src/${fileName}`, `scripts/${fileName}`]
        };
      case '.html':
        return {
          path: `public/${fileName}`,
          reason: "HTML file - placing in public directory",
          confidence: 85,
          alternatives: [`src/${fileName}`, fileName]
        };
      default:
        return {
          path: `src/${fileName}`,
          reason: "General code file - placing in src directory",
          confidence: 60,
          alternatives: [fileName, `lib/${fileName}`]
        };
    }
  }

  private async assessConflictRisk(
    suggestedPath: string, 
    content: string, 
    extractedFiles: Record<string, string>
  ): Promise<'low' | 'medium' | 'high'> {
    try {
      // Check if file already exists
      await fs.access(suggestedPath);
      
      // File exists - check for conflicts
      const existingContent = await fs.readFile(suggestedPath, 'utf-8');
      
      if (existingContent === content) {
        return 'low'; // Identical content
      }
      
      // Check for function name conflicts
      const existingFunctions = this.extractFunctionNames(existingContent);
      const newFunctions = this.extractFunctionNames(content);
      const conflicts = existingFunctions.filter(fn => newFunctions.includes(fn));
      
      if (conflicts.length > 0) {
        return 'high';
      }
      
      return 'medium'; // File exists but no obvious conflicts
      
    } catch (error) {
      return 'low'; // File doesn't exist
    }
  }

  private extractFunctionNames(content: string): string[] {
    const functions: string[] = [];
    const patterns = [
      /function\s+(\w+)/g,
      /const\s+(\w+)\s*=/g,
      /export\s+function\s+(\w+)/g,
      /export\s+const\s+(\w+)/g
    ];
    
    patterns.forEach(pattern => {
      let match;
      while ((match = pattern.exec(content)) !== null) {
        functions.push(match[1]);
      }
    });
    
    return functions;
  }

  private async scanDirectory(dir: string): Promise<{ files: string[]; directories: string[] }> {
    const files: string[] = [];
    const directories: string[] = [];
    
    try {
      const entries = await fs.readdir(dir, { withFileTypes: true });
      
      for (const entry of entries) {
        if (entry.name.startsWith('.')) continue; // Skip hidden files
        
        if (entry.isDirectory()) {
          directories.push(entry.name);
        } else {
          files.push(entry.name);
        }
      }
    } catch (error) {
      // Directory doesn't exist or not accessible
    }
    
    return { files, directories };
  }

  private async readPackageJson(): Promise<any> {
    try {
      const content = await fs.readFile('package.json', 'utf-8');
      return JSON.parse(content);
    } catch (error) {
      return {};
    }
  }

  private detectFrameworks(packageJson: any): string[] {
    const frameworks: string[] = [];
    const deps = { ...packageJson.dependencies, ...packageJson.devDependencies };
    
    if (deps.react) frameworks.push('React');
    if (deps.vue) frameworks.push('Vue');
    if (deps.angular) frameworks.push('Angular');
    if (deps.express) frameworks.push('Express');
    if (deps.fastify) frameworks.push('Fastify');
    if (deps.next) frameworks.push('Next.js');
    if (deps.nuxt) frameworks.push('Nuxt.js');
    
    return frameworks;
  }

  private findTestDirectory(directories: string[]): string {
    const testDirs = directories.filter(dir => 
      dir.includes('test') || dir.includes('spec') || dir.includes('__tests__')
    );
    return testDirs[0] || '__tests__';
  }
}

export const filePlacementService = new FilePlacementService();