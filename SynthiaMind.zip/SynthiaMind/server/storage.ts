import { 
  type User, 
  type InsertUser,
  type CodeProject,
  type InsertCodeProject,
  type CodeAnalysis,
  type InsertCodeAnalysis,
  type IntegrationHistory,
  type InsertIntegrationHistory,
  type BrainState,
  type InsertBrainState,
  type Experiment,
  type InsertExperiment,
  type Gate,
  type Quest
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Code Projects
  createCodeProject(project: InsertCodeProject): Promise<CodeProject>;
  getCodeProject(id: string): Promise<CodeProject | undefined>;
  getAllCodeProjects(): Promise<CodeProject[]>;
  updateCodeProject(id: string, updates: Partial<CodeProject>): Promise<CodeProject | undefined>;
  
  // Code Analysis
  createCodeAnalysis(analysis: InsertCodeAnalysis): Promise<CodeAnalysis>;
  getCodeAnalysisByProject(projectId: string): Promise<CodeAnalysis[]>;
  getCodeAnalysisById(id: string): Promise<CodeAnalysis | undefined>;
  
  // Integration History
  createIntegrationHistory(history: InsertIntegrationHistory): Promise<IntegrationHistory>;
  getIntegrationHistory(projectId: string): Promise<IntegrationHistory[]>;
  getActiveIntegration(projectId: string): Promise<IntegrationHistory | undefined>;
  deactivateIntegration(id: string): Promise<void>;
  
  // Brain States
  createBrainState(state: InsertBrainState): Promise<BrainState>;
  getLatestBrainState(): Promise<BrainState | undefined>;
  getBrainStateHistory(limit?: number): Promise<BrainState[]>;
  
  // Experiments
  createExperiment(experiment: InsertExperiment): Promise<Experiment>;
  getExperiment(id: string): Promise<Experiment | undefined>;
  getAllExperiments(): Promise<Experiment[]>;
  updateExperiment(id: string, updates: Partial<Experiment>): Promise<Experiment | undefined>;
  
  // Gates & Quests
  getAllGates(): Promise<Gate[]>;
  unlockGate(gateNumber: number): Promise<Gate | undefined>;
  getAllQuests(): Promise<Quest[]>;
  updateQuestProgress(id: string, progress: number): Promise<Quest | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User> = new Map();
  private codeProjects: Map<string, CodeProject> = new Map();
  private codeAnalysis: Map<string, CodeAnalysis> = new Map();
  private integrationHistory: Map<string, IntegrationHistory> = new Map();
  private brainStates: Map<string, BrainState> = new Map();
  private experiments: Map<string, Experiment> = new Map();
  private gates: Map<number, Gate> = new Map();
  private quests: Map<string, Quest> = new Map();

  constructor() {
    this.initializeGates();
    this.initializeQuests();
  }

  private initializeGates() {
    // Initialize all 64 gates
    for (let i = 1; i <= 64; i++) {
      const gate: Gate = {
        id: randomUUID(),
        gateNumber: i,
        isUnlocked: i <= 8, // First 8 gates unlocked by default
        unlockedAt: i <= 8 ? new Date() : null,
        layer: Math.ceil(i / 21.33), // Distribute across 3 layers
      };
      this.gates.set(i, gate);
    }
  }

  private initializeQuests() {
    const defaultQuests: Omit<Quest, 'id'>[] = [
      {
        title: "Integrate 5 external functions safely",
        description: "Successfully integrate 5 functions from external code without conflicts",
        type: "integration",
        targetCount: 5,
        currentProgress: 3,
        isCompleted: false,
        reward: "Unlock 3 new gates",
        createdAt: new Date(),
      },
      {
        title: "Analyze 10 code files",
        description: "Run AST analysis on 10 different code files",
        type: "analysis",
        targetCount: 10,
        currentProgress: 7,
        isCompleted: false,
        reward: "Enhanced code understanding",
        createdAt: new Date(),
      },
      {
        title: "Complete field coherence experiment",
        description: "Run and complete a field coherence measurement experiment",
        type: "experiment",
        targetCount: 1,
        currentProgress: 0,
        isCompleted: false,
        reward: "Unlock advanced brain synchronization",
        createdAt: new Date(),
      }
    ];

    defaultQuests.forEach(quest => {
      const id = randomUUID();
      this.quests.set(id, { ...quest, id });
    });
  }

  // User methods
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Code Project methods
  async createCodeProject(project: InsertCodeProject): Promise<CodeProject> {
    const id = randomUUID();
    const codeProject: CodeProject = {
      ...project,
      id,
      createdAt: new Date(),
    };
    this.codeProjects.set(id, codeProject);
    return codeProject;
  }

  async getCodeProject(id: string): Promise<CodeProject | undefined> {
    return this.codeProjects.get(id);
  }

  async getAllCodeProjects(): Promise<CodeProject[]> {
    return Array.from(this.codeProjects.values()).sort((a, b) => 
      new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime()
    );
  }

  async updateCodeProject(id: string, updates: Partial<CodeProject>): Promise<CodeProject | undefined> {
    const project = this.codeProjects.get(id);
    if (!project) return undefined;
    
    const updated = { ...project, ...updates };
    this.codeProjects.set(id, updated);
    return updated;
  }

  // Code Analysis methods
  async createCodeAnalysis(analysis: InsertCodeAnalysis): Promise<CodeAnalysis> {
    const id = randomUUID();
    const codeAnalysis: CodeAnalysis = {
      ...analysis,
      id,
      createdAt: new Date(),
    };
    this.codeAnalysis.set(id, codeAnalysis);
    return codeAnalysis;
  }

  async getCodeAnalysisByProject(projectId: string): Promise<CodeAnalysis[]> {
    return Array.from(this.codeAnalysis.values())
      .filter(analysis => analysis.projectId === projectId);
  }

  async getCodeAnalysisById(id: string): Promise<CodeAnalysis | undefined> {
    return this.codeAnalysis.get(id);
  }

  // Integration History methods
  async createIntegrationHistory(history: InsertIntegrationHistory): Promise<IntegrationHistory> {
    const id = randomUUID();
    const integrationHistory: IntegrationHistory = {
      ...history,
      id,
      createdAt: new Date(),
    };
    this.integrationHistory.set(id, integrationHistory);
    return integrationHistory;
  }

  async getIntegrationHistory(projectId: string): Promise<IntegrationHistory[]> {
    return Array.from(this.integrationHistory.values())
      .filter(history => history.projectId === projectId)
      .sort((a, b) => new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime());
  }

  async getActiveIntegration(projectId: string): Promise<IntegrationHistory | undefined> {
    return Array.from(this.integrationHistory.values())
      .find(history => history.projectId === projectId && history.isActive);
  }

  async deactivateIntegration(id: string): Promise<void> {
    const history = this.integrationHistory.get(id);
    if (history) {
      this.integrationHistory.set(id, { ...history, isActive: false });
    }
  }

  // Brain State methods
  async createBrainState(state: InsertBrainState): Promise<BrainState> {
    const id = randomUUID();
    const brainState: BrainState = {
      ...state,
      id,
      timestamp: new Date(),
    };
    this.brainStates.set(id, brainState);
    return brainState;
  }

  async getLatestBrainState(): Promise<BrainState | undefined> {
    const states = Array.from(this.brainStates.values())
      .sort((a, b) => new Date(b.timestamp!).getTime() - new Date(a.timestamp!).getTime());
    return states[0];
  }

  async getBrainStateHistory(limit: number = 50): Promise<BrainState[]> {
    return Array.from(this.brainStates.values())
      .sort((a, b) => new Date(b.timestamp!).getTime() - new Date(a.timestamp!).getTime())
      .slice(0, limit);
  }

  // Experiment methods
  async createExperiment(experiment: InsertExperiment): Promise<Experiment> {
    const id = randomUUID();
    const exp: Experiment = {
      ...experiment,
      id,
      createdAt: new Date(),
    };
    this.experiments.set(id, exp);
    return exp;
  }

  async getExperiment(id: string): Promise<Experiment | undefined> {
    return this.experiments.get(id);
  }

  async getAllExperiments(): Promise<Experiment[]> {
    return Array.from(this.experiments.values())
      .sort((a, b) => new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime());
  }

  async updateExperiment(id: string, updates: Partial<Experiment>): Promise<Experiment | undefined> {
    const experiment = this.experiments.get(id);
    if (!experiment) return undefined;
    
    const updated = { ...experiment, ...updates };
    this.experiments.set(id, updated);
    return updated;
  }

  // Gates & Quests methods
  async getAllGates(): Promise<Gate[]> {
    return Array.from(this.gates.values()).sort((a, b) => a.gateNumber - b.gateNumber);
  }

  async unlockGate(gateNumber: number): Promise<Gate | undefined> {
    const gate = this.gates.get(gateNumber);
    if (!gate) return undefined;
    
    const updated = { ...gate, isUnlocked: true, unlockedAt: new Date() };
    this.gates.set(gateNumber, updated);
    return updated;
  }

  async getAllQuests(): Promise<Quest[]> {
    return Array.from(this.quests.values())
      .sort((a, b) => new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime());
  }

  async updateQuestProgress(id: string, progress: number): Promise<Quest | undefined> {
    const quest = this.quests.get(id);
    if (!quest) return undefined;
    
    const updated = { 
      ...quest, 
      currentProgress: progress,
      isCompleted: progress >= quest.targetCount 
    };
    this.quests.set(id, updated);
    return updated;
  }
}

export const storage = new MemStorage();
