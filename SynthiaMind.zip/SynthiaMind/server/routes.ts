import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { ZipExtractor } from "./services/zip-extractor";
import { CodeAnalysisService } from "./services/code-analysis";
import { SandboxRunner } from "./services/sandbox-runner";
import { openaiService } from "./services/openai-service";
import { filePlacementService } from "./services/file-placement";
import multer from "multer";
import { z } from "zod";

// Initialize services
const zipExtractor = new ZipExtractor();
const codeAnalysisService = new CodeAnalysisService();
const sandboxRunner = new SandboxRunner();

// Configure multer for file uploads
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 50 * 1024 * 1024, // 50MB limit
  },
  fileFilter: (req: any, file: any, cb: any) => {
    // Accept ZIP files and common code files
    const allowedTypes = [
      'application/zip',
      'application/x-zip-compressed',
      'text/plain',
      'text/javascript',
      'application/javascript',
      'text/x-python',
      'text/x-java-source',
      'text/x-c',
      'text/x-c++',
      'text/html',
      'text/css',
      'application/json',
      'text/xml',
      'application/xml'
    ];
    
    if (allowedTypes.includes(file.mimetype) || 
        file.originalname.match(/\.(zip|js|ts|jsx|tsx|py|java|cpp|c|cs|php|rb|go|rs|swift|kt|scala|clj|hs|ml|elm|dart|lua|r|m|pl|sh|bat|html|css|json|xml|yaml|yml|md|txt)$/i)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type. Please upload ZIP files or code files.'), false);
    }
  }
});

const createProjectSchema = z.object({
  name: z.string().min(1),
  description: z.string().optional(),
});

const chatMessageSchema = z.object({
  message: z.string().min(1),
  context: z.object({
    recentIntegrations: z.array(z.string()).optional(),
    activeExperiments: z.array(z.string()).optional(),
  }).optional()
});

const naturalLanguageSchema = z.object({
  instruction: z.string().min(1),
  codebaseContext: z.string().optional(),
  fileList: z.array(z.string()).optional()
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Get all projects
  app.get("/api/projects", async (req, res) => {
    try {
      const projects = await storage.getAllCodeProjects();
      res.json(projects);
    } catch (error) {
      console.error("Error fetching projects:", error);
      res.status(500).json({ error: "Failed to fetch projects" });
    }
  });

  // Create new project with ZIP upload or multiple files
  app.post("/api/projects", upload.array('files', 20), async (req, res) => {
    try {
      const body = createProjectSchema.parse(req.body);
      
      if (!req.files || (req.files as Express.Multer.File[]).length === 0) {
        return res.status(400).json({ error: "At least one file is required" });
      }

      const files = req.files as Express.Multer.File[];
      let extractionResult: { files: Record<string, string>; totalFiles: number; totalSize: number; structure: any };

      // Handle ZIP files vs individual files
      if (files.length === 1 && files[0].originalname.endsWith('.zip')) {
        // Single ZIP file
        extractionResult = await zipExtractor.extractZip(files[0].buffer);
      } else {
        // Multiple individual files
        const filesMap: Record<string, string> = {};
        let totalSize = 0;
        
        for (const file of files) {
          filesMap[file.originalname] = file.buffer.toString('utf-8');
          totalSize += file.size;
        }
        
        extractionResult = {
          files: filesMap,
          totalFiles: files.length,
          totalSize,
          structure: Object.keys(filesMap).map(name => ({ path: name, type: 'file' }))
        };
      }
      
      // Create project
      const project = await storage.createCodeProject({
        name: body.name,
        description: body.description,
        zipData: req.file.buffer.toString('base64'),
        extractedFiles: extractionResult.files,
        userId: null, // No auth in this version
      });

      // Analyze code files 
      const codeFiles = files.length === 1 && files[0].originalname.endsWith('.zip') 
        ? zipExtractor.filterCodeFiles(extractionResult.files)
        : extractionResult.files;
      
      const analysisPromises = Object.entries(codeFiles).map(async ([filename, content]) => {
        if (codeAnalysisService.isAnalyzableFile(filename)) {
          try {
            // Get AST analysis for JS/TS files
            let astAnalysis = null;
            if (filename.match(/\.(js|jsx|ts|tsx)$/)) {
              astAnalysis = await codeAnalysisService.analyzeJavaScriptFile(filename, content);
            }

            // Get AI analysis
            const aiAnalysis = await codeAnalysisService.analyzeFileWithAI(filename, content, codeFiles);

            return await storage.createCodeAnalysis({
              projectId: project.id,
              fileName: filename,
              fileType: codeAnalysisService.getFileType(filename),
              astData: astAnalysis,
              functions: aiAnalysis.functions,
              imports: aiAnalysis.imports,
              exports: aiAnalysis.exports,
              compatibility: aiAnalysis.compatibility,
            });
          } catch (error) {
            console.error(`Failed to analyze ${filename}:`, error);
            return null;
          }
        }
        return null;
      });

      const analyses = (await Promise.all(analysisPromises)).filter(Boolean);

      res.json({
        project,
        extractionResult: {
          totalFiles: extractionResult.totalFiles,
          totalSize: extractionResult.totalSize,
          structure: extractionResult.structure
        },
        analyses: analyses.length
      });
    } catch (error) {
      console.error("Error creating project:", error);
      res.status(500).json({ error: "Failed to create project" });
    }
  });

  // Get project details with analysis
  app.get("/api/projects/:id", async (req, res) => {
    try {
      const project = await storage.getCodeProject(req.params.id);
      if (!project) {
        return res.status(404).json({ error: "Project not found" });
      }

      const analyses = await storage.getCodeAnalysisByProject(project.id);
      const integrationHistory = await storage.getIntegrationHistory(project.id);

      res.json({
        project,
        analyses,
        integrationHistory
      });
    } catch (error) {
      console.error("Error fetching project:", error);
      res.status(500).json({ error: "Failed to fetch project" });
    }
  });

  // Analyze integration compatibility
  app.post("/api/projects/:id/analyze-integration", async (req, res) => {
    try {
      const project = await storage.getCodeProject(req.params.id);
      if (!project) {
        return res.status(404).json({ error: "Project not found" });
      }

      if (!project.extractedFiles) {
        return res.status(400).json({ error: "No files to analyze" });
      }

      const analyses = await storage.getCodeAnalysisByProject(project.id);
      
      // Get current application files (simplified - in real app would read from filesystem)
      const currentFiles = {
        'src/App.tsx': '// Current app code...',
        'src/lib/utils.ts': '// Current utils...',
        // This would be populated with actual current codebase files
      };

      // Make integration decision using AI
      const decision = await openAIService.makeIntegrationDecision(
        currentFiles,
        project.extractedFiles,
        analyses.map(a => ({
          compatibility: a.compatibility || 0,
          functions: a.functions || [],
          imports: a.imports || [],
          exports: a.exports || [],
          recommendations: [],
          risks: []
        }))
      );

      res.json({
        decision,
        analyses,
        compatibilityScore: Math.round(analyses.reduce((acc, a) => acc + (a.compatibility || 0), 0) / analyses.length)
      });
    } catch (error) {
      console.error("Error analyzing integration:", error);
      res.status(500).json({ error: "Failed to analyze integration" });
    }
  });

  // Execute integration
  app.post("/api/projects/:id/integrate", async (req, res) => {
    try {
      const project = await storage.getCodeProject(req.params.id);
      if (!project) {
        return res.status(404).json({ error: "Project not found" });
      }

      const { selectedFiles } = req.body;
      
      if (!Array.isArray(selectedFiles) || selectedFiles.length === 0) {
        return res.status(400).json({ error: "No files selected for integration" });
      }

      // Test integration in sandbox
      const testResults = [];
      for (const filename of selectedFiles) {
        const fileContent = project.extractedFiles?.[filename];
        if (fileContent) {
          const result = await sandboxRunner.runJavaScript(fileContent);
          testResults.push({
            filename,
            result
          });
        }
      }

      // Create integration history record
      const integration = await storage.createIntegrationHistory({
        projectId: project.id,
        integratedFiles: selectedFiles,
        changes: selectedFiles.map(file => ({
          type: 'add' as const,
          file,
          content: project.extractedFiles?.[file] || ''
        })),
        rollbackData: { /* rollback info */ },
        isActive: true
      });

      res.json({
        integration,
        testResults,
        success: testResults.every(t => t.result.success)
      });
    } catch (error) {
      console.error("Error executing integration:", error);
      res.status(500).json({ error: "Failed to execute integration" });
    }
  });

  // Rollback integration
  app.post("/api/integrations/:id/rollback", async (req, res) => {
    try {
      await storage.deactivateIntegration(req.params.id);
      res.json({ success: true });
    } catch (error) {
      console.error("Error rolling back integration:", error);
      res.status(500).json({ error: "Failed to rollback integration" });
    }
  });

  // Brain state endpoints
  app.get("/api/brain-state", async (req, res) => {
    try {
      const latestState = await storage.getLatestBrainState();
      res.json(latestState || { mind: 75, heart: 60, body: 80, resonance: 85 });
    } catch (error) {
      console.error("Error fetching brain state:", error);
      res.status(500).json({ error: "Failed to fetch brain state" });
    }
  });

  app.post("/api/brain-state", async (req, res) => {
    try {
      const { mind, heart, body, resonance } = req.body;
      const state = await storage.createBrainState({ mind, heart, body, resonance });
      res.json(state);
    } catch (error) {
      console.error("Error updating brain state:", error);
      res.status(500).json({ error: "Failed to update brain state" });
    }
  });

  app.get("/api/brain-state/history", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 50;
      const history = await storage.getBrainStateHistory(limit);
      res.json(history);
    } catch (error) {
      console.error("Error fetching brain state history:", error);
      res.status(500).json({ error: "Failed to fetch brain state history" });
    }
  });

  // Natural language instruction processing
  app.post("/api/natural-language", async (req, res) => {
    try {
      const body = naturalLanguageSchema.parse(req.body);
      
      // Get current codebase context
      const projects = await storage.getAllCodeProjects();
      const fileList = projects.flatMap(p => 
        p.extractedFiles ? Object.keys(p.extractedFiles) : []
      );
      
      const codebaseContext = projects.map(p => 
        `Project: ${p.name}\nFiles: ${Object.keys(p.extractedFiles || {}).join(', ')}`
      ).join('\n\n');

      // Process the instruction with AI
      const processedInstruction = await openaiService.processNaturalLanguageInstruction({
        instruction: body.instruction,
        codebaseContext,
        fileList
      });

      // Generate implementation suggestions and analyze compatibility
      const implementations = [];
      for (const step of processedInstruction.actionPlan) {
        try {
          const suggestion = await openaiService.generateCodeSuggestion(
            codebaseContext,
            step.implementation,
            step.targetFiles.length > 0 ? `Target files: ${step.targetFiles.join(', ')}` : undefined
          );
          
          // Generate file placement suggestions for each step
          const placementSuggestions = [];
          if (step.targetFiles && step.targetFiles.length > 0) {
            for (const targetFile of step.targetFiles) {
              const placement = await filePlacementService.suggestFilePlacement(
                targetFile,
                suggestion.code || '',
                {}
              );
              placementSuggestions.push(placement);
            }
          }
          
          implementations.push({
            step: step.step,
            action: step.action,
            targetFiles: step.targetFiles,
            generatedCode: suggestion.code,
            explanation: suggestion.explanation,
            filePlacement: placementSuggestions
          });
        } catch (error) {
          console.error(`Failed to generate suggestion for step ${step.step}:`, error);
          implementations.push({
            step: step.step,
            action: step.action,
            targetFiles: step.targetFiles,
            generatedCode: '',
            explanation: 'Failed to generate implementation',
            filePlacement: []
          });
        }
      }

      res.json({
        processedInstruction,
        implementations,
        estimatedTime: `${processedInstruction.estimatedComplexity * 15} minutes`,
        safetyChecks: processedInstruction.safetyChecks
      });
    } catch (error) {
      console.error("Error processing natural language instruction:", error);
      res.status(500).json({ 
        error: "Failed to process instruction",
        details: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // Consciousness chat endpoint
  app.post("/api/chat", async (req, res) => {
    try {
      const body = chatMessageSchema.parse(req.body);
      
      const brainState = await storage.getLatestBrainState();
      const brainStates = {
        mind: brainState?.mind || 75,
        heart: brainState?.heart || 60,
        body: brainState?.body || 80
      };

      const context = {
        recentIntegrations: body.context?.recentIntegrations || [],
        activeExperiments: body.context?.activeExperiments || []
      };

      // For now, return a simple response since full consciousness chat needs OpenAI
      const response = `Brain state - Mind: ${brainStates.mind}%, Heart: ${brainStates.heart}%, Body: ${brainStates.body}%. Processing message: "${body.message}"`;

      res.json({ response });
    } catch (error) {
      console.error("Error processing chat message:", error);
      res.status(500).json({ error: "Failed to process message" });
    }
  });

  // Experiments endpoints
  app.get("/api/experiments", async (req, res) => {
    try {
      const experiments = await storage.getAllExperiments();
      res.json(experiments);
    } catch (error) {
      console.error("Error fetching experiments:", error);
      res.status(500).json({ error: "Failed to fetch experiments" });
    }
  });

  app.post("/api/experiments", async (req, res) => {
    try {
      const { name, type } = req.body;
      const experiment = await storage.createExperiment({
        name,
        type,
        status: 'running',
        startedAt: new Date(),
        fieldInterference: Math.floor(Math.random() * 100),
        coherenceLevel: Math.floor(Math.random() * 100)
      });

      // Simulate experiment completion after 5 seconds
      setTimeout(async () => {
        await storage.updateExperiment(experiment.id, {
          status: 'complete',
          completedAt: new Date(),
          results: { success: true, data: 'Experiment completed successfully' }
        });
      }, 5000);

      res.json(experiment);
    } catch (error) {
      console.error("Error creating experiment:", error);
      res.status(500).json({ error: "Failed to create experiment" });
    }
  });

  // Gates and quests endpoints
  app.get("/api/gates", async (req, res) => {
    try {
      const gates = await storage.getAllGates();
      res.json(gates);
    } catch (error) {
      console.error("Error fetching gates:", error);
      res.status(500).json({ error: "Failed to fetch gates" });
    }
  });

  app.get("/api/quests", async (req, res) => {
    try {
      const quests = await storage.getAllQuests();
      res.json(quests);
    } catch (error) {
      console.error("Error fetching quests:", error);
      res.status(500).json({ error: "Failed to fetch quests" });
    }
  });

  // WebSocket support for real-time updates would go here
  const httpServer = createServer(app);

  return httpServer;
}
