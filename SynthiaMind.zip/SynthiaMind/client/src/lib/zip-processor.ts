import JSZip from 'jszip';

export interface ExtractedFile {
  path: string;
  content: string;
  size: number;
  isDirectory: boolean;
  type: string;
}

export interface ExtractionResult {
  files: Record<string, string>;
  structure: ExtractedFile[];
  totalFiles: number;
  totalSize: number;
  codeFiles: Record<string, string>;
}

export interface DirectoryNode {
  name: string;
  type: 'file' | 'directory';
  path: string;
  size?: number;
  children?: DirectoryNode[];
  isExpanded?: boolean;
}

export class ZipProcessor {
  private static readonly MAX_FILE_SIZE = 5 * 1024 * 1024; // 5MB per file
  private static readonly MAX_TOTAL_SIZE = 50 * 1024 * 1024; // 50MB total
  private static readonly CODE_EXTENSIONS = new Set([
    'js', 'jsx', 'ts', 'tsx', 'py', 'java', 'c', 'cpp', 'cs', 'php', 'rb', 'go', 'rs', 'swift',
    'html', 'css', 'scss', 'sass', 'less', 'vue', 'svelte', 'json', 'yaml', 'yml', 'xml', 'sql',
    'md', 'txt', 'config', 'env'
  ]);

  static async extractFromFile(file: File): Promise<ExtractionResult> {
    if (!file.name.toLowerCase().endsWith('.zip')) {
      throw new Error('File must be a ZIP archive');
    }

    if (file.size > this.MAX_TOTAL_SIZE) {
      throw new Error(`ZIP file too large. Maximum size is ${this.MAX_TOTAL_SIZE / 1024 / 1024}MB`);
    }

    const arrayBuffer = await file.arrayBuffer();
    return this.extractFromBuffer(arrayBuffer);
  }

  static async extractFromBuffer(buffer: ArrayBuffer): Promise<ExtractionResult> {
    try {
      const zip = new JSZip();
      const zipContent = await zip.loadAsync(buffer);
      
      const files: Record<string, string> = {};
      const structure: ExtractedFile[] = [];
      const codeFiles: Record<string, string> = {};
      let totalSize = 0;

      // Process all files in the ZIP
      for (const [relativePath, zipEntry] of Object.entries(zipContent.files)) {
        if (zipEntry.dir) {
          // Directory entry
          structure.push({
            path: relativePath,
            content: '',
            size: 0,
            isDirectory: true,
            type: 'directory'
          });
        } else {
          try {
            // Check file size before extracting
            const fileSize = zipEntry._data?.uncompressedSize || 0;
            if (fileSize > this.MAX_FILE_SIZE) {
              console.warn(`Skipping large file ${relativePath} (${fileSize} bytes)`);
              continue;
            }

            const content = await zipEntry.async('text');
            const actualSize = content.length;
            
            totalSize += actualSize;
            if (totalSize > this.MAX_TOTAL_SIZE) {
              throw new Error('ZIP content too large after extraction');
            }

            const fileType = this.getFileType(relativePath);
            files[relativePath] = content;
            
            structure.push({
              path: relativePath,
              content,
              size: actualSize,
              isDirectory: false,
              type: fileType
            });

            // Filter code files
            if (this.isCodeFile(relativePath)) {
              codeFiles[relativePath] = content;
            }
          } catch (error) {
            console.warn(`Failed to extract file ${relativePath}:`, error);
            // Skip binary files or files that can't be read as text
          }
        }
      }

      return {
        files,
        structure,
        codeFiles,
        totalFiles: Object.keys(files).length,
        totalSize
      };
    } catch (error) {
      console.error('ZIP extraction failed:', error);
      throw new Error(`Failed to extract ZIP file: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  static getFileType(filename: string): string {
    const ext = filename.split('.').pop()?.toLowerCase();
    switch (ext) {
      case 'js': return 'javascript';
      case 'jsx': return 'jsx';
      case 'ts': return 'typescript';
      case 'tsx': return 'tsx';
      case 'py': return 'python';
      case 'html': return 'html';
      case 'css': return 'css';
      case 'scss': case 'sass': return 'scss';
      case 'json': return 'json';
      case 'md': return 'markdown';
      case 'vue': return 'vue';
      case 'svelte': return 'svelte';
      case 'yaml': case 'yml': return 'yaml';
      case 'xml': return 'xml';
      case 'sql': return 'sql';
      case 'txt': return 'text';
      default: return 'unknown';
    }
  }

  static isCodeFile(filename: string): boolean {
    const extension = filename.split('.').pop()?.toLowerCase();
    return extension ? this.CODE_EXTENSIONS.has(extension) : false;
  }

  static buildDirectoryTree(structure: ExtractedFile[]): DirectoryNode[] {
    const root: Record<string, DirectoryNode> = {};
    
    // Sort structure by path to ensure directories come before files
    const sortedStructure = [...structure].sort((a, b) => {
      if (a.isDirectory && !b.isDirectory) return -1;
      if (!a.isDirectory && b.isDirectory) return 1;
      return a.path.localeCompare(b.path);
    });
    
    sortedStructure.forEach(file => {
      const parts = file.path.split('/').filter(part => part.length > 0);
      let current = root;
      
      parts.forEach((part, index) => {
        const isLast = index === parts.length - 1;
        const currentPath = parts.slice(0, index + 1).join('/');
        
        if (!current[part]) {
          current[part] = {
            name: part,
            type: (isLast && !file.isDirectory) ? 'file' : 'directory',
            path: currentPath,
            size: (isLast && !file.isDirectory) ? file.size : undefined,
            children: {},
            isExpanded: index < 2, // Auto-expand first 2 levels
          } as DirectoryNode & { children: any };
        }
        
        if (!isLast || file.isDirectory) {
          current = current[part].children;
        }
      });
    });

    const convertToArray = (nodes: any): DirectoryNode[] => {
      return Object.values(nodes).map((node: any) => ({
        ...node,
        children: node.type === 'directory' ? convertToArray(node.children) : undefined,
      }));
    };

    return convertToArray(root);
  }

  static filterFilesByType(files: Record<string, string>, types: string[]): Record<string, string> {
    const filtered: Record<string, string> = {};
    
    Object.entries(files).forEach(([path, content]) => {
      const fileType = this.getFileType(path);
      if (types.includes(fileType)) {
        filtered[path] = content;
      }
    });
    
    return filtered;
  }

  static getProjectInfo(structure: ExtractedFile[]): {
    hasPackageJson: boolean;
    hasPython: boolean;
    hasJavaScript: boolean;
    hasTypeScript: boolean;
    hasHTML: boolean;
    mainLanguage: string;
    complexity: 'low' | 'medium' | 'high';
  } {
    const files = structure.filter(f => !f.isDirectory);
    const extensions = files.map(f => f.path.split('.').pop()?.toLowerCase()).filter(Boolean);
    const extensionCounts = extensions.reduce((acc, ext) => {
      acc[ext!] = (acc[ext!] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    const hasPackageJson = files.some(f => f.path.includes('package.json'));
    const hasPython = extensions.some(ext => ext === 'py');
    const hasJavaScript = extensions.some(ext => ['js', 'jsx'].includes(ext!));
    const hasTypeScript = extensions.some(ext => ['ts', 'tsx'].includes(ext!));
    const hasHTML = extensions.some(ext => ext === 'html');

    // Determine main language
    let mainLanguage = 'unknown';
    const maxExt = Object.entries(extensionCounts).reduce((a, b) => a[1] > b[1] ? a : b, ['', 0]);
    
    if (maxExt[1] > 0) {
      switch (maxExt[0]) {
        case 'js':
        case 'jsx':
          mainLanguage = 'javascript';
          break;
        case 'ts':
        case 'tsx':
          mainLanguage = 'typescript';
          break;
        case 'py':
          mainLanguage = 'python';
          break;
        case 'html':
          mainLanguage = 'html';
          break;
        case 'css':
        case 'scss':
          mainLanguage = 'css';
          break;
        default:
          mainLanguage = maxExt[0];
      }
    }

    // Determine complexity
    let complexity: 'low' | 'medium' | 'high' = 'low';
    const totalFiles = files.length;
    const totalSize = files.reduce((sum, f) => sum + f.size, 0);
    
    if (totalFiles > 50 || totalSize > 1024 * 1024) {
      complexity = 'high';
    } else if (totalFiles > 20 || totalSize > 512 * 1024) {
      complexity = 'medium';
    }

    return {
      hasPackageJson,
      hasPython,
      hasJavaScript,
      hasTypeScript,
      hasHTML,
      mainLanguage,
      complexity
    };
  }

  static validateZipContent(structure: ExtractedFile[]): {
    isValid: boolean;
    errors: string[];
    warnings: string[];
  } {
    const errors: string[] = [];
    const warnings: string[] = [];

    const files = structure.filter(f => !f.isDirectory);
    
    // Check for suspicious files
    const suspiciousPatterns = [
      /\.exe$/i,
      /\.dll$/i,
      /\.bat$/i,
      /\.sh$/i,
      /\.scr$/i,
      /password/i,
      /secret/i,
      /private.*key/i
    ];

    files.forEach(file => {
      const filename = file.path.toLowerCase();
      
      suspiciousPatterns.forEach(pattern => {
        if (pattern.test(filename)) {
          warnings.push(`Potentially sensitive file detected: ${file.path}`);
        }
      });

      // Check for very large files
      if (file.size > 1024 * 1024) { // 1MB
        warnings.push(`Large file detected: ${file.path} (${(file.size / 1024 / 1024).toFixed(1)}MB)`);
      }
    });

    // Check for reasonable project structure
    if (files.length === 0) {
      errors.push('No files found in ZIP archive');
    }

    if (files.length > 500) {
      warnings.push('Very large project (500+ files) - processing may be slow');
    }

    return {
      isValid: errors.length === 0,
      errors,
      warnings
    };
  }
}
