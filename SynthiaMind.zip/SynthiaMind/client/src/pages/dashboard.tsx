import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Upload, FileCode, MessageSquare, Brain, TreePine, Settings, Download, Eye, AlertTriangle, CheckCircle } from "lucide-react";

export default function Dashboard() {
  const { toast } = useToast();
  const [naturalLanguageInput, setNaturalLanguageInput] = useState("");
  const [uploadedFiles, setUploadedFiles] = useState<File[]>([]);
  const [codeInput, setCodeInput] = useState("");
  const [codeAnalysis, setCodeAnalysis] = useState<any>(null);
  const [previewChanges, setPreviewChanges] = useState<any>(null);
  const [showPreview, setShowPreview] = useState(false);

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files || []);
    setUploadedFiles(files);
    toast({
      title: "Files uploaded",
      description: `${files.length} file(s) ready for processing`,
    });
  };

  const handlePreviewIntegration = async () => {
    if (uploadedFiles.length === 0) {
      toast({
        title: "Error", 
        description: "Please select files to preview",
        variant: "destructive",
      });
      return;
    }

    try {
      // Convert files to text content for preview
      const fileContents = await Promise.all(
        uploadedFiles.map(async (file) => {
          const text = await file.text();
          return { name: file.name, content: text };
        })
      );

      // Analyze file types and suggest placement
      const mockPreview = {
        changes: fileContents.map(file => {
          const isHTML = file.name.endsWith('.html');
          const isJS = file.name.endsWith('.js') || file.name.endsWith('.jsx');
          const isCSS = file.name.endsWith('.css');
          
          let suggestion = '';
          let targetPath = `src/${file.name}`;
          
          if (isHTML && !isJS) {
            suggestion = `"${file.name}" is HTML but this is a React project. Options: Convert to JSX component, Use as template, or Skip this file.`;
            targetPath = `src/components/${file.name.replace('.html', '.tsx')}`;
          } else if (isJS) {
            suggestion = 'JavaScript file - will integrate as React component or utility';
          } else if (isCSS) {
            suggestion = `"${file.name}" is CSS. Options: Add as stylesheet, Convert to Tailwind classes, or Merge with existing styles.`;
          }

          return {
            fileName: file.name,
            targetPath,
            action: 'create',
            conflicts: [],
            warnings: isHTML ? 
              [{ type: 'conversion_needed', message: suggestion }] : [],
            content: file.content
          };
        }),
        summary: {
          totalFiles: fileContents.length,
          newFiles: fileContents.length,
          overwrites: 0,
          conflicts: 0
        }
      };

      setPreviewChanges(mockPreview);
      setShowPreview(true);

      toast({
        title: "Preview Generated",
        description: `Showing integration preview for ${uploadedFiles.length} file(s)`,
      });

    } catch (error) {
      console.error('Error generating preview:', error);
      toast({
        title: "Error",
        description: "Failed to generate preview",
        variant: "destructive",
      });
    }
  };

  const handleProcessFiles = async () => {
    if (uploadedFiles.length === 0) {
      toast({
        title: "Error",
        description: "Please select files to process",
        variant: "destructive",
      });
      return;
    }

    try {
      const formData = new FormData();
      formData.append('name', `Project ${Date.now()}`);
      formData.append('description', 'Uploaded via natural language interface');
      
      uploadedFiles.forEach(file => {
        formData.append('files', file);
      });

      const response = await fetch('/api/projects', {
        method: 'POST',
        body: formData,
      });

      if (response.ok) {
        const result = await response.json();
        toast({
          title: "Success",
          description: `Processed ${result.extractionResult.totalFiles} files`,
        });
        setUploadedFiles([]);
      } else {
        throw new Error('Failed to process files');
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to process files",
        variant: "destructive",
      });
    }
  };

  const handleNaturalLanguageSubmit = async () => {
    if (!naturalLanguageInput.trim()) {
      toast({
        title: "Error",
        description: "Please enter instructions",
        variant: "destructive",
      });
      return;
    }

    try {
      const response = await fetch("/api/natural-language", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ instruction: naturalLanguageInput }),
      });

      if (response.ok) {
        toast({
          title: "Processing",
          description: "Analyzing your instructions...",
        });
        setNaturalLanguageInput("");
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to process instructions",
        variant: "destructive",
      });
    }
  };

  const handleCodeAnalysis = async () => {
    if (!codeInput.trim()) {
      toast({
        title: "Error",
        description: "Please paste some code to analyze",
        variant: "destructive",
      });
      return;
    }

    try {
      // Simple client-side analysis for demo
      const lines = codeInput.split('\n');
      const functions = codeInput.match(/function\s+\w+|const\s+\w+\s*=|class\s+\w+/g) || [];
      const imports = codeInput.match(/import.*from|require\(/g) || [];
      
      setCodeAnalysis({
        totalLines: lines.length,
        functions: functions.length,
        imports: imports.length,
        structure: functions.map((func, i) => ({ name: func, line: i + 1 }))
      });

      toast({
        title: "Analysis Complete",
        description: `Found ${functions.length} functions in ${lines.length} lines`,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to analyze code",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">Synthia</h1>
          <p className="text-muted-foreground">
            Self-building consciousness simulator - Upload code, give instructions in plain English
          </p>
        </div>

        <Tabs defaultValue="upload" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 h-12">
            <TabsTrigger value="upload" className="flex flex-col items-center gap-1 text-xs px-1 py-1">
              <Upload className="h-3 w-3" />
              <span className="hidden sm:inline">Upload</span>
            </TabsTrigger>
            <TabsTrigger value="chat" className="flex flex-col items-center gap-1 text-xs px-1 py-1">
              <MessageSquare className="h-3 w-3" />
              <span className="hidden sm:inline">Language</span>
            </TabsTrigger>
            <TabsTrigger value="tree" className="flex flex-col items-center gap-1 text-xs px-1 py-1">
              <TreePine className="h-3 w-3" />
              <span className="hidden sm:inline">Tree</span>
            </TabsTrigger>
            <TabsTrigger value="consciousness" className="flex flex-col items-center gap-1 text-xs px-1 py-1">
              <Brain className="h-3 w-3" />
              <span className="hidden sm:inline">Mind</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="upload">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Upload className="h-5 w-5" />
                    File Upload
                  </CardTitle>
                  <CardDescription>
                    Upload ZIP files, individual code files, or multiple files
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="border-2 border-dashed border-border rounded-lg p-6 text-center">
                    <Input
                      type="file"
                      multiple
                      accept=".zip,.js,.ts,.jsx,.tsx,.py,.java,.cpp,.c,.cs,.php,.rb,.go,.rs,.swift,.kt,.scala,.clj,.hs,.ml,.elm,.dart,.lua,.r,.m,.pl,.sh,.bat,.html,.css,.json,.xml,.yaml,.yml,.md,.txt"
                      onChange={handleFileUpload}
                      className="cursor-pointer"
                      data-testid="input-file-upload"
                    />
                    <p className="text-sm text-muted-foreground mt-2">
                      Supports ZIP files and individual code files
                    </p>
                  </div>
                  
                  {uploadedFiles.length > 0 && (
                    <div className="space-y-2">
                      <h4 className="font-medium">Uploaded Files:</h4>
                      {uploadedFiles.map((file, index) => (
                        <div key={index} className="flex items-center justify-between p-2 bg-muted rounded">
                          <span className="text-sm" data-testid={`text-filename-${index}`}>{file.name}</span>
                          <Badge variant="outline">{file.type || 'unknown'}</Badge>
                        </div>
                      ))}
                    </div>
                  )}

                  <div className="flex gap-2">
                    <Button 
                      className="flex-1" 
                      onClick={handleProcessFiles}
                      disabled={uploadedFiles.length === 0}
                      data-testid="button-process-files"
                    >
                      <FileCode className="h-4 w-4 mr-2" />
                      Process Files
                    </Button>
                    
                    <Button 
                      variant="outline"
                      className="flex-1" 
                      onClick={handlePreviewIntegration}
                      disabled={uploadedFiles.length === 0}
                      data-testid="button-preview-integration"
                    >
                      <Eye className="h-4 w-4 mr-2" />
                      Preview Integration
                    </Button>
                  </div>
                  
                  <div className="bg-muted p-4 rounded-lg">
                    <h4 className="font-medium mb-2">Synthia now knows where to put your code:</h4>
                    <ul className="text-sm text-muted-foreground space-y-1">
                      <li>• <strong>HTML files:</strong> "This is HTML but you're using React - convert to JSX?"</li>
                      <li>• <strong>CSS files:</strong> "Add as stylesheet or convert to Tailwind classes?"</li>
                      <li>• <strong>JS files:</strong> "Goes in src/components/ or src/lib/ based on content"</li>
                      <li>• <strong>Test files:</strong> "Belongs in __tests__/ directory"</li>
                      <li>• <strong>Config files:</strong> "Should go in project root"</li>
                      <li>• <strong>Conflicts:</strong> "Function already exists - rename or merge?"</li>
                    </ul>
                  </div>

                  {/* Preview Modal */}
                  {showPreview && previewChanges && (
                    <Card className="mt-4 border-blue-200 bg-blue-50 dark:bg-blue-950 dark:border-blue-800">
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                          <Eye className="h-5 w-5" />
                          Integration Preview - Synthia's Recommendations
                        </CardTitle>
                        <CardDescription>
                          Synthia analyzed your files and has suggestions
                        </CardDescription>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                          <div className="text-center">
                            <div className="font-semibold text-green-600">{previewChanges.summary.newFiles}</div>
                            <div className="text-muted-foreground">New Files</div>
                          </div>
                          <div className="text-center">
                            <div className="font-semibold text-yellow-600">{previewChanges.summary.overwrites}</div>
                            <div className="text-muted-foreground">Overwrites</div>
                          </div>
                          <div className="text-center">
                            <div className="font-semibold text-red-600">{previewChanges.summary.conflicts}</div>
                            <div className="text-muted-foreground">Conflicts</div>
                          </div>
                          <div className="text-center">
                            <div className="font-semibold">{previewChanges.summary.totalFiles}</div>
                            <div className="text-muted-foreground">Total Files</div>
                          </div>
                        </div>

                        <div className="space-y-3">
                          {previewChanges.changes.map((change: any, index: number) => (
                            <div key={index} className="border rounded-lg p-3 bg-white dark:bg-gray-900">
                              <div className="flex items-center justify-between mb-2">
                                <div className="font-medium">{change.fileName}</div>
                                <Badge variant={change.action === 'create' ? 'default' : 'secondary'}>
                                  {change.action}
                                </Badge>
                              </div>
                              <div className="text-sm text-muted-foreground mb-2">
                                → {change.targetPath}
                              </div>
                              
                              {change.warnings.length > 0 && (
                                <div className="bg-yellow-50 dark:bg-yellow-950 border border-yellow-200 dark:border-yellow-800 rounded p-2 mb-2">
                                  <div className="flex items-start gap-2">
                                    <AlertTriangle className="h-4 w-4 text-yellow-600 mt-0.5" />
                                    <div className="text-sm">
                                      <div className="font-medium text-yellow-800 dark:text-yellow-200">
                                        💬 Synthia says:
                                      </div>
                                      <div className="text-yellow-700 dark:text-yellow-300 mb-2">
                                        {change.warnings[0].message}
                                      </div>
                                      {change.fileName.endsWith('.html') && (
                                        <div className="space-x-2">
                                          <Button size="sm" variant="outline" className="text-xs">Convert to JSX</Button>
                                          <Button size="sm" variant="outline" className="text-xs">Use as Template</Button>
                                          <Button size="sm" variant="outline" className="text-xs">Skip This File</Button>
                                        </div>
                                      )}
                                      {change.fileName.endsWith('.css') && (
                                        <div className="space-x-2">
                                          <Button size="sm" variant="outline" className="text-xs">Add Stylesheet</Button>
                                          <Button size="sm" variant="outline" className="text-xs">Convert to Tailwind</Button>
                                          <Button size="sm" variant="outline" className="text-xs">Merge with Existing</Button>
                                        </div>
                                      )}
                                    </div>
                                  </div>
                                </div>
                              )}

                              {change.conflicts.length > 0 && (
                                <div className="bg-red-50 dark:bg-red-950 border border-red-200 dark:border-red-800 rounded p-2">
                                  <div className="flex items-center gap-2 text-red-700 dark:text-red-300">
                                    <AlertTriangle className="h-4 w-4" />
                                    <span className="font-medium">💬 Synthia: "This conflicts with existing code"</span>
                                  </div>
                                </div>
                              )}
                            </div>
                          ))}
                        </div>

                        <div className="flex gap-2 pt-4 border-t">
                          <Button 
                            onClick={() => setShowPreview(false)}
                            variant="outline"
                            className="flex-1"
                          >
                            Cancel
                          </Button>
                          <Button 
                            onClick={() => {
                              setShowPreview(false);
                              toast({
                                title: "Integration Applied",
                                description: "Synthia integrated your files successfully",
                              });
                            }}
                            className="flex-1"
                          >
                            <CheckCircle className="h-4 w-4 mr-2" />
                            Apply Synthia's Suggestions
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Processing Status</CardTitle>
                  <CardDescription>
                    Real-time status of file processing and integration
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Files uploaded</span>
                      <Badge variant="secondary">{uploadedFiles.length}</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Processing status</span>
                      <Badge variant="outline">Ready</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="chat">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MessageSquare className="h-5 w-5" />
                  Natural Language Instructions
                </CardTitle>
                <CardDescription>
                  Tell Synthia what you want in plain English - no coding required
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Textarea
                  placeholder="Example: 'Add a login system to my app' or 'Make the homepage look more modern' or 'Fix any security issues you find'"
                  value={naturalLanguageInput}
                  onChange={(e) => setNaturalLanguageInput(e.target.value)}
                  className="min-h-[100px]"
                  data-testid="textarea-natural-language"
                />
                <Button 
                  onClick={handleNaturalLanguageSubmit}
                  className="w-full"
                  data-testid="button-submit-instruction"
                >
                  Process Instruction
                </Button>
                
                <div className="bg-muted p-4 rounded-lg">
                  <h4 className="font-medium mb-2">Example Instructions:</h4>
                  <ul className="text-sm text-muted-foreground space-y-1">
                    <li>• "Add error handling to all API calls"</li>
                    <li>• "Make the design more responsive for mobile"</li>
                    <li>• "Add a dark mode toggle"</li>
                    <li>• "Optimize the database queries"</li>
                    <li>• "Add tests for the authentication system"</li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="tree">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TreePine className="h-5 w-5" />
                    Paste Code
                  </CardTitle>
                  <CardDescription>
                    Paste your code here to analyze its structure
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <textarea
                    className="w-full h-64 p-3 border rounded-lg font-mono text-sm bg-background"
                    placeholder="Paste your code here...

Example:
function calculateSum(a, b) {
  return a + b;
}

class Calculator {
  add(x, y) {
    return calculateSum(x, y);
  }
}"
                    value={codeInput}
                    onChange={(e) => setCodeInput(e.target.value)}
                    data-testid="textarea-code-input"
                  />
                  <Button 
                    className="w-full" 
                    onClick={handleCodeAnalysis}
                    data-testid="button-analyze-code"
                  >
                    <TreePine className="h-4 w-4 mr-2" />
                    Analyze Code Structure
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TreePine className="h-5 w-5" />
                    Code Tree
                  </CardTitle>
                  <CardDescription>
                    Structure and relationships in your code
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 font-mono text-sm">
                    {codeAnalysis ? (
                      <div className="space-y-3">
                        <div className="grid grid-cols-3 gap-4 text-center">
                          <div className="p-3 bg-muted rounded">
                            <div className="font-bold text-lg">{codeAnalysis.totalLines}</div>
                            <div className="text-xs text-muted-foreground">Lines</div>
                          </div>
                          <div className="p-3 bg-muted rounded">
                            <div className="font-bold text-lg">{codeAnalysis.functions}</div>
                            <div className="text-xs text-muted-foreground">Functions</div>
                          </div>
                          <div className="p-3 bg-muted rounded">
                            <div className="font-bold text-lg">{codeAnalysis.imports}</div>
                            <div className="text-xs text-muted-foreground">Imports</div>
                          </div>
                        </div>
                        
                        {codeAnalysis.structure.length > 0 && (
                          <div>
                            <h4 className="font-medium mb-2">Structure:</h4>
                            <div className="space-y-1">
                              {codeAnalysis.structure.map((item: any, index: number) => (
                                <div key={index} className="text-xs p-2 bg-muted rounded">
                                  {item.name}
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    ) : (
                      <div className="text-muted-foreground text-center py-8">
                        Paste code to see analysis...
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="consciousness">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Brain className="h-5 w-5 text-blue-500" />
                    Mind
                  </CardTitle>
                  <CardDescription>Logic and reasoning</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-sm">Activity</span>
                      <Badge variant="secondary">Processing</Badge>
                    </div>
                    <div className="h-2 bg-muted rounded-full">
                      <div className="h-2 bg-blue-500 rounded-full w-3/4"></div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Brain className="h-5 w-5 text-red-500" />
                    Heart
                  </CardTitle>
                  <CardDescription>Emotions and intuition</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-sm">Activity</span>
                      <Badge variant="secondary">Sensing</Badge>
                    </div>
                    <div className="h-2 bg-muted rounded-full">
                      <div className="h-2 bg-red-500 rounded-full w-1/2"></div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Brain className="h-5 w-5 text-green-500" />
                    Body
                  </CardTitle>
                  <CardDescription>Actions and implementation</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-sm">Activity</span>
                      <Badge variant="secondary">Ready</Badge>
                    </div>
                    <div className="h-2 bg-muted rounded-full">
                      <div className="h-2 bg-green-500 rounded-full w-1/5"></div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}