import { useEffect, useRef, useState, useCallback } from 'react';

export interface WebSocketMessage {
  type: string;
  data: any;
  timestamp?: string;
}

export interface UseWebSocketOptions {
  url: string;
  reconnectInterval?: number;
  maxReconnectAttempts?: number;
  onOpen?: () => void;
  onMessage?: (message: WebSocketMessage) => void;
  onError?: (error: Event) => void;
  onClose?: () => void;
}

export interface UseWebSocketReturn {
  isConnected: boolean;
  isConnecting: boolean;
  sendMessage: (message: WebSocketMessage) => void;
  lastMessage: WebSocketMessage | null;
  connectionState: 'connecting' | 'connected' | 'disconnected' | 'error';
  reconnectAttempts: number;
}

export function useWebSocket(options: UseWebSocketOptions): UseWebSocketReturn {
  const {
    url,
    reconnectInterval = 3000,
    maxReconnectAttempts = 5,
    onOpen,
    onMessage,
    onError,
    onClose
  } = options;

  const [isConnected, setIsConnected] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const [lastMessage, setLastMessage] = useState<WebSocketMessage | null>(null);
  const [connectionState, setConnectionState] = useState<'connecting' | 'connected' | 'disconnected' | 'error'>('disconnected');
  const [reconnectAttempts, setReconnectAttempts] = useState(0);

  const wsRef = useRef<WebSocket | null>(null);
  const reconnectTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const shouldReconnectRef = useRef(true);

  const connect = useCallback(() => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      return;
    }

    setIsConnecting(true);
    setConnectionState('connecting');

    try {
      const ws = new WebSocket(url);
      wsRef.current = ws;

      ws.onopen = () => {
        setIsConnected(true);
        setIsConnecting(false);
        setConnectionState('connected');
        setReconnectAttempts(0);
        onOpen?.();
      };

      ws.onmessage = (event) => {
        try {
          const message: WebSocketMessage = JSON.parse(event.data);
          setLastMessage(message);
          onMessage?.(message);
        } catch (error) {
          console.error('Failed to parse WebSocket message:', error);
        }
      };

      ws.onerror = (error) => {
        setConnectionState('error');
        onError?.(error);
      };

      ws.onclose = () => {
        setIsConnected(false);
        setIsConnecting(false);
        setConnectionState('disconnected');
        wsRef.current = null;
        onClose?.();

        // Attempt to reconnect if enabled and within limits
        if (shouldReconnectRef.current && reconnectAttempts < maxReconnectAttempts) {
          setReconnectAttempts(prev => prev + 1);
          reconnectTimeoutRef.current = setTimeout(() => {
            connect();
          }, reconnectInterval);
        }
      };
    } catch (error) {
      setIsConnecting(false);
      setConnectionState('error');
      console.error('Failed to create WebSocket connection:', error);
    }
  }, [url, reconnectInterval, maxReconnectAttempts, reconnectAttempts, onOpen, onMessage, onError, onClose]);

  const sendMessage = useCallback((message: WebSocketMessage) => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      try {
        const messageWithTimestamp = {
          ...message,
          timestamp: new Date().toISOString()
        };
        wsRef.current.send(JSON.stringify(messageWithTimestamp));
      } catch (error) {
        console.error('Failed to send WebSocket message:', error);
      }
    } else {
      console.warn('WebSocket is not connected. Message not sent:', message);
    }
  }, []);

  const disconnect = useCallback(() => {
    shouldReconnectRef.current = false;
    
    if (reconnectTimeoutRef.current) {
      clearTimeout(reconnectTimeoutRef.current);
      reconnectTimeoutRef.current = null;
    }

    if (wsRef.current) {
      wsRef.current.close();
      wsRef.current = null;
    }

    setIsConnected(false);
    setIsConnecting(false);
    setConnectionState('disconnected');
  }, []);

  // Connect on mount
  useEffect(() => {
    shouldReconnectRef.current = true;
    connect();

    return () => {
      disconnect();
    };
  }, [connect, disconnect]);

  // Clean up on unmount
  useEffect(() => {
    return () => {
      disconnect();
    };
  }, [disconnect]);

  return {
    isConnected,
    isConnecting,
    sendMessage,
    lastMessage,
    connectionState,
    reconnectAttempts
  };
}

// Hook specifically for consciousness data streaming
export function useConsciousnessStream() {
  const [brainState, setBrainState] = useState({ mind: 75, heart: 60, body: 80, resonance: 85 });
  const [experiments, setExperiments] = useState<any[]>([]);
  const [liveData, setLiveData] = useState<any[]>([]);

  const { isConnected, sendMessage, lastMessage } = useWebSocket({
    url: `ws://${window.location.host}/ws/consciousness`,
    onMessage: (message) => {
      switch (message.type) {
        case 'brain_state_update':
          setBrainState(message.data);
          break;
        case 'experiment_update':
          setExperiments(prev => {
            const updated = [...prev];
            const index = updated.findIndex(exp => exp.id === message.data.id);
            if (index >= 0) {
              updated[index] = message.data;
            } else {
              updated.push(message.data);
            }
            return updated;
          });
          break;
        case 'live_data':
          setLiveData(prev => [...prev.slice(-49), message.data]); // Keep last 50 entries
          break;
      }
    }
  });

  const updateBrainState = useCallback((newState: Partial<typeof brainState>) => {
    sendMessage({
      type: 'update_brain_state',
      data: newState
    });
  }, [sendMessage]);

  const startExperiment = useCallback((experiment: { name: string; type: string }) => {
    sendMessage({
      type: 'start_experiment',
      data: experiment
    });
  }, [sendMessage]);

  return {
    isConnected,
    brainState,
    experiments,
    liveData,
    updateBrainState,
    startExperiment
  };
}

// Hook for integration status updates
export function useIntegrationStream() {
  const [integrationStatus, setIntegrationStatus] = useState<any>(null);
  const [codeChanges, setCodeChanges] = useState<any[]>([]);

  const { isConnected, sendMessage } = useWebSocket({
    url: `ws://${window.location.host}/ws/integration`,
    onMessage: (message) => {
      switch (message.type) {
        case 'integration_progress':
          setIntegrationStatus(message.data);
          break;
        case 'code_change':
          setCodeChanges(prev => [...prev.slice(-99), message.data]); // Keep last 100 changes
          break;
      }
    }
  });

  const requestIntegration = useCallback((projectId: string, files: string[]) => {
    sendMessage({
      type: 'request_integration',
      data: { projectId, files }
    });
  }, [sendMessage]);

  const rollbackIntegration = useCallback((integrationId: string) => {
    sendMessage({
      type: 'rollback_integration',
      data: { integrationId }
    });
  }, [sendMessage]);

  return {
    isConnected,
    integrationStatus,
    codeChanges,
    requestIntegration,
    rollbackIntegration
  };
}
