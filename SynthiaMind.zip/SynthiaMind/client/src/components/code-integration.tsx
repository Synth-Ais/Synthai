import { useState, useCallback } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { CloudUpload, Shield, AlertTriangle } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface CodeIntegrationProps {
  projects?: any[];
}

export default function CodeIntegration({ projects }: CodeIntegrationProps) {
  const [dragActive, setDragActive] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [analysisResults, setAnalysisResults] = useState<any>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const uploadMutation = useMutation({
    mutationFn: async (formData: FormData) => {
      const response = await apiRequest('POST', '/api/projects', formData);
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Upload Successful",
        description: `Analyzed ${data.analyses} files from ${data.project.name}`,
      });
      queryClient.invalidateQueries({ queryKey: ['/api/projects'] });
      setUploadProgress(100);
      setTimeout(() => setUploadProgress(0), 2000);
    },
    onError: (error) => {
      toast({
        title: "Upload Failed",
        description: "Failed to process ZIP file. Please try again.",
        variant: "destructive",
      });
      setUploadProgress(0);
    }
  });

  const analyzeIntegrationMutation = useMutation({
    mutationFn: async (projectId: string) => {
      const response = await apiRequest('POST', `/api/projects/${projectId}/analyze-integration`);
      return response.json();
    },
    onSuccess: (data) => {
      setAnalysisResults(data);
    }
  });

  const integrationMutation = useMutation({
    mutationFn: async ({ projectId, selectedFiles }: { projectId: string; selectedFiles: string[] }) => {
      const response = await apiRequest('POST', `/api/projects/${projectId}/integrate`, {
        selectedFiles
      });
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Integration Complete",
        description: data.success ? "Code integrated successfully" : "Integration completed with warnings",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/projects'] });
    }
  });

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileUpload(e.dataTransfer.files[0]);
    }
  }, []);

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFileUpload(e.target.files[0]);
    }
  };

  const handleFileUpload = (file: File) => {
    if (!file.name.endsWith('.zip')) {
      toast({
        title: "Invalid File",
        description: "Please upload a ZIP file.",
        variant: "destructive",
      });
      return;
    }

    const formData = new FormData();
    formData.append('zipFile', file);
    formData.append('name', file.name.replace('.zip', ''));
    formData.append('description', `Uploaded from ${file.name}`);

    setUploadProgress(10);
    uploadMutation.mutate(formData);
  };

  const latestProject = projects?.[0];

  return (
    <Card className="bg-dark-matter/60 backdrop-blur-md border-void rounded-2xl p-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-semibold">Self-Building Engine</h2>
        <div className="flex items-center space-x-2">
          <span className="text-xs text-integration">Safe Mode</span>
          <div className="w-3 h-3 bg-integration rounded-full"></div>
        </div>
      </div>
      
      {/* File Upload Zone */}
      <div
        className={`border-2 border-dashed rounded-lg p-8 text-center mb-4 transition-all cursor-pointer ${
          dragActive 
            ? 'border-consciousness/70 bg-consciousness/10' 
            : 'border-consciousness/30 hover:border-consciousness/50'
        }`}
        onDragEnter={handleDrag}
        onDragLeave={handleDrag}
        onDragOver={handleDrag}
        onDrop={handleDrop}
        onClick={() => document.getElementById('file-input')?.click()}
        data-testid="file-upload-zone"
      >
        <input
          id="file-input"
          type="file"
          accept=".zip"
          onChange={handleFileInputChange}
          className="hidden"
          data-testid="input-file"
        />
        
        <div className="w-16 h-16 bg-consciousness/10 rounded-full flex items-center justify-center mx-auto mb-4">
          <CloudUpload className="text-consciousness text-2xl" />
        </div>
        <p className="text-lg font-medium mb-2">Drop ZIP files or click to upload</p>
        <p className="text-sm text-muted-essence">I'll analyze and safely integrate useful code</p>
      </div>
      
      {/* Upload Progress */}
      {uploadProgress > 0 && (
        <div className="mb-4">
          <div className="flex items-center justify-between text-sm mb-2">
            <span>Processing Upload...</span>
            <span className="text-integration">{uploadProgress}%</span>
          </div>
          <Progress value={uploadProgress} className="h-2" />
        </div>
      )}
      
      {/* Integration Progress */}
      {latestProject && (
        <div className="space-y-3">
          <div className="flex items-center justify-between text-sm">
            <span>Latest Project: {latestProject.name}</span>
            <Button
              size="sm"
              variant="outline"
              onClick={() => analyzeIntegrationMutation.mutate(latestProject.id)}
              disabled={analyzeIntegrationMutation.isPending}
              className="border-consciousness/40 text-consciousness hover:bg-consciousness/10"
              data-testid="button-analyze-integration"
            >
              <Shield className="w-4 h-4 mr-1" />
              Analyze Integration
            </Button>
          </div>
          
          {analysisResults && (
            <div className="bg-void/30 rounded-lg p-4 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Compatibility Score</span>
                <span className={`text-sm font-mono ${
                  analysisResults.compatibilityScore > 70 ? 'text-integration' : 
                  analysisResults.compatibilityScore > 40 ? 'text-disruption' : 'text-destructive'
                }`}>
                  {analysisResults.compatibilityScore}%
                </span>
              </div>
              
              <Progress value={analysisResults.compatibilityScore} className="h-2" />
              
              <div className="flex items-center justify-between text-xs text-muted-essence">
                <span>{analysisResults.analyses?.length || 0} functions analyzed</span>
                <span>{analysisResults.decision?.suggestedChanges?.length || 0} integration points found</span>
              </div>
              
              {analysisResults.decision?.shouldIntegrate && (
                <Button
                  size="sm"
                  onClick={() => integrationMutation.mutate({
                    projectId: latestProject.id,
                    selectedFiles: analysisResults.decision.suggestedChanges.map((c: any) => c.file)
                  })}
                  disabled={integrationMutation.isPending}
                  className="w-full bg-integration hover:bg-integration/80"
                  data-testid="button-integrate-code"
                >
                  {integrationMutation.isPending ? 'Integrating...' : 'Integrate Selected Code'}
                </Button>
              )}
              
              {analysisResults.decision?.potentialConflicts?.length > 0 && (
                <div className="flex items-start space-x-2 text-xs text-destructive">
                  <AlertTriangle className="w-4 h-4 mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="font-medium">Potential Conflicts:</p>
                    <ul className="list-disc list-inside">
                      {analysisResults.decision.potentialConflicts.map((conflict: string, index: number) => (
                        <li key={index}>{conflict}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </Card>
  );
}
