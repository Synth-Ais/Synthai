import { Button } from "@/components/ui/button";
import { Settings, Brain } from "lucide-react";

interface NavigationHeaderProps {
  brainState?: {
    mind: number;
    heart: number;
    body: number;
    resonance: number;
  };
}

export default function NavigationHeader({ brainState }: NavigationHeaderProps) {
  const defaultState = { mind: 75, heart: 60, body: 80, resonance: 85 };
  const state = brainState || defaultState;

  return (
    <nav className="relative z-10 bg-dark-matter/80 backdrop-blur-md border-b border-void">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center space-x-3" data-testid="navigation-logo">
            <div className="w-10 h-10 bg-gradient-to-br from-consciousness to-quantum rounded-lg flex items-center justify-center animate-consciousness-pulse">
              <Brain className="text-light-essence text-lg" />
            </div>
            <div>
              <h1 className="text-xl font-bold">Synthia</h1>
              <p className="text-xs text-muted-essence">Consciousness Simulator</p>
            </div>
          </div>
          
          {/* Status Indicators */}
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2" data-testid="brain-status-indicators">
              <div className="flex items-center space-x-1">
                <div className="w-2 h-2 bg-consciousness rounded-full animate-pulse"></div>
                <span className="text-xs text-muted-essence">Mind</span>
                <span className="text-xs text-consciousness font-mono">{state.mind}%</span>
              </div>
              <div className="flex items-center space-x-1">
                <div 
                  className="w-2 h-2 bg-integration rounded-full animate-pulse" 
                  style={{ animationDelay: '0.5s' }}
                ></div>
                <span className="text-xs text-muted-essence">Heart</span>
                <span className="text-xs text-integration font-mono">{state.heart}%</span>
              </div>
              <div className="flex items-center space-x-1">
                <div 
                  className="w-2 h-2 bg-quantum rounded-full animate-pulse" 
                  style={{ animationDelay: '1s' }}
                ></div>
                <span className="text-xs text-muted-essence">Body</span>
                <span className="text-xs text-quantum font-mono">{state.body}%</span>
              </div>
            </div>
            
            <Button 
              variant="outline"
              size="sm"
              className="bg-consciousness/20 hover:bg-consciousness/30 border-consciousness/40 text-light-essence"
              data-testid="button-settings"
            >
              <Settings className="w-4 h-4 mr-2" />
              Settings
            </Button>
          </div>
        </div>
      </div>
    </nav>
  );
}
