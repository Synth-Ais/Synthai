import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";

interface Gate {
  id: string;
  gateNumber: number;
  isUnlocked: boolean;
  unlockedAt?: Date | null;
  layer: number;
}

interface Quest {
  id: string;
  title: string;
  description: string;
  type: string;
  targetCount: number;
  currentProgress: number;
  isCompleted: boolean;
  reward?: string;
}

interface GatesSystemProps {
  gates?: Gate[];
  quests?: Quest[];
}

export default function GatesSystem({ gates, quests }: GatesSystemProps) {
  // Default data for demonstration
  const defaultGates: Gate[] = Array.from({ length: 16 }, (_, i) => ({
    id: `gate-${i + 1}`,
    gateNumber: i + 1,
    isUnlocked: i < 8, // First 8 unlocked
    unlockedAt: i < 8 ? new Date() : null,
    layer: Math.ceil((i + 1) / 5.33),
  }));

  const defaultQuests: Quest[] = [
    {
      id: '1',
      title: 'Integrate 5 external functions safely',
      description: 'Successfully integrate 5 functions from external code without conflicts',
      type: 'integration',
      targetCount: 5,
      currentProgress: 3,
      isCompleted: false,
      reward: 'Unlock 3 new gates',
    }
  ];

  const gatesData = gates || defaultGates;
  const questsData = quests || defaultQuests;
  const activeQuest = questsData.find(q => !q.isCompleted);
  
  const unlockedCount = gatesData.filter(g => g.isUnlocked).length;
  const completedQuests = questsData.filter(q => q.isCompleted).length;
  const totalIntegrations = 27; // This would come from actual integration history

  return (
    <Card className="bg-dark-matter/60 backdrop-blur-md border-void rounded-2xl p-6">
      <h2 className="text-lg font-semibold mb-4">Gates & Quests</h2>
      
      {/* Active Quest */}
      {activeQuest && (
        <div className="bg-consciousness/10 border border-consciousness/20 rounded-lg p-3 mb-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-consciousness">Active Quest</span>
            <span className="text-xs text-muted-essence">
              {activeQuest.currentProgress}/{activeQuest.targetCount} steps
            </span>
          </div>
          <p className="text-xs text-muted-essence mb-2">{activeQuest.title}</p>
          <Progress 
            value={(activeQuest.currentProgress / activeQuest.targetCount) * 100} 
            className="h-1"
          />
        </div>
      )}
      
      {/* Gates Grid - showing first 16 gates */}
      <div className="grid grid-cols-8 gap-1 mb-4">
        {gatesData.slice(0, 16).map((gate) => (
          <div
            key={gate.id}
            className={`w-6 h-6 border rounded text-xs flex items-center justify-center cursor-pointer transition-colors ${
              gate.isUnlocked
                ? gate.gateNumber === 4
                  ? 'bg-consciousness/20 border-consciousness/40 text-consciousness animate-pulse hover:bg-consciousness/30'
                  : 'bg-integration/20 border-integration/40 text-integration hover:bg-integration/30'
                : 'bg-void/30 border-void/60 text-muted-essence/50 cursor-not-allowed'
            }`}
            data-testid={`gate-${gate.gateNumber}`}
            title={gate.isUnlocked ? `Gate ${gate.gateNumber} - Unlocked` : `Gate ${gate.gateNumber} - Locked`}
          >
            {gate.gateNumber}
          </div>
        ))}
      </div>
      
      {/* Stats */}
      <div className="grid grid-cols-3 gap-3 text-center text-xs">
        <div>
          <div className="font-mono text-lg font-bold text-integration" data-testid="stat-unlocked-gates">
            {unlockedCount}
          </div>
          <div className="text-muted-essence">Gates</div>
        </div>
        <div>
          <div className="font-mono text-lg font-bold text-consciousness" data-testid="stat-completed-quests">
            {completedQuests}
          </div>
          <div className="text-muted-essence">Quests</div>
        </div>
        <div>
          <div className="font-mono text-lg font-bold text-quantum" data-testid="stat-integrations">
            {totalIntegrations}
          </div>
          <div className="text-muted-essence">Integrations</div>
        </div>
      </div>
    </Card>
  );
}
