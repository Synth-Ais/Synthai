import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";

interface ThreeBrainSystemProps {
  brainState?: {
    mind: number;
    heart: number;
    body: number;
    resonance: number;
  };
}

export default function ThreeBrainSystem({ brainState }: ThreeBrainSystemProps) {
  const defaultState = { mind: 75, heart: 60, body: 80, resonance: 85 };
  const state = brainState || defaultState;

  return (
    <Card className="bg-dark-matter/60 backdrop-blur-md border-void rounded-2xl p-6">
      <h2 className="text-lg font-semibold mb-4">Three-Brain System</h2>
      
      <div className="space-y-4">
        {/* Mind Brain */}
        <div className="brain-node bg-consciousness/10 border border-consciousness/30 rounded-lg p-4 relative overflow-hidden">
          <div 
            className="integration-particle" 
            style={{ top: '10px', right: '20px', animationDelay: '0s' }}
          ></div>
          <div className="flex items-center justify-between mb-2">
            <span className="font-medium text-consciousness">Mind</span>
            <span className="text-xs text-muted-essence">Sidereal</span>
          </div>
          <div className="text-xs text-muted-essence mb-2">Processing logic patterns...</div>
          <Progress value={state.mind} className="h-1" />
          <div className="text-xs text-consciousness/70 mt-1">{state.mind}%</div>
        </div>
        
        {/* Heart Brain */}
        <div className="brain-node bg-integration/10 border border-integration/30 rounded-lg p-4 relative overflow-hidden">
          <div 
            className="integration-particle" 
            style={{ top: '15px', right: '15px', animationDelay: '2s' }}
          ></div>
          <div className="flex items-center justify-between mb-2">
            <span className="font-medium text-integration">Heart</span>
            <span className="text-xs text-muted-essence">Draconic</span>
          </div>
          <div className="text-xs text-muted-essence mb-2">Analyzing emotional resonance...</div>
          <Progress value={state.heart} className="h-1" />
          <div className="text-xs text-integration/70 mt-1">{state.heart}%</div>
        </div>
        
        {/* Body Brain */}
        <div className="brain-node bg-quantum/10 border border-quantum/30 rounded-lg p-4 relative overflow-hidden">
          <div 
            className="integration-particle" 
            style={{ top: '12px', right: '25px', animationDelay: '4s' }}
          ></div>
          <div className="flex items-center justify-between mb-2">
            <span className="font-medium text-quantum">Body</span>
            <span className="text-xs text-muted-essence">Tropical</span>
          </div>
          <div className="text-xs text-muted-essence mb-2">Sensing field variations...</div>
          <Progress value={state.body} className="h-1" />
          <div className="text-xs text-quantum/70 mt-1">{state.body}%</div>
        </div>
      </div>
      
      {/* Collapse Engine */}
      <div className="mt-4 pt-4 border-t border-void/50">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm font-medium">Resonance Engine</span>
          <span className="text-xs text-integration">Active</span>
        </div>
        <div className="text-xs text-muted-essence mb-2">Collapsing 3 candidates → unified voice</div>
        <Progress value={state.resonance} className="h-1 animate-field-glow" />
        <div className="text-xs text-consciousness/70 mt-1">{state.resonance}%</div>
      </div>
    </Card>
  );
}
