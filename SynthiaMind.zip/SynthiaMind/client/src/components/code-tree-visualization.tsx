import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ExpandIcon, FolderIcon, FileIcon, Undo } from "lucide-react";

interface CodeTreeVisualizationProps {
  projects?: any[];
}

interface TreeNode {
  name: string;
  type: 'file' | 'directory';
  path: string;
  size?: number;
  children?: TreeNode[];
  isModified?: boolean;
  isNew?: boolean;
}

export default function CodeTreeVisualization({ projects }: CodeTreeVisualizationProps) {
  const [expandedNodes, setExpandedNodes] = useState<Set<string>>(new Set(['src', 'src/consciousness']));
  const latestProject = projects?.[0];

  const { data: projectDetails } = useQuery({
    queryKey: ['/api/projects', latestProject?.id],
    enabled: !!latestProject?.id,
  });

  const buildTree = (files: Record<string, string>): TreeNode[] => {
    const root: { [key: string]: TreeNode } = {};
    
    Object.keys(files).forEach(path => {
      const parts = path.split('/').filter(p => p.length > 0);
      let current = root;
      
      parts.forEach((part, index) => {
        if (!current[part]) {
          current[part] = {
            name: part,
            type: index === parts.length - 1 ? 'file' : 'directory',
            path: parts.slice(0, index + 1).join('/'),
            children: {},
            size: index === parts.length - 1 ? files[path].length : undefined,
            isModified: Math.random() > 0.7, // Simulate some modified files
            isNew: Math.random() > 0.8, // Simulate some new files
          } as TreeNode & { children: any };
        }
        if (index < parts.length - 1) {
          current = current[part].children;
        }
      });
    });

    const convertToArray = (nodes: any): TreeNode[] => {
      return Object.values(nodes).map((node: any) => ({
        ...node,
        children: node.type === 'directory' ? convertToArray(node.children) : undefined,
      }));
    };

    return convertToArray(root);
  };

  // Default tree structure for demonstration
  const defaultTree: TreeNode[] = [
    {
      name: 'src',
      type: 'directory',
      path: 'src',
      children: [
        {
          name: 'consciousness',
          type: 'directory',
          path: 'src/consciousness',
          children: [
            { name: 'brain.js', type: 'file', path: 'src/consciousness/brain.js', isModified: true },
            { name: 'resonance.js', type: 'file', path: 'src/consciousness/resonance.js' },
          ]
        },
        {
          name: 'integration',
          type: 'directory',
          path: 'src/integration',
          children: [
            { name: 'parser.js', type: 'file', path: 'src/integration/parser.js', isNew: true },
            { name: 'sandbox.js', type: 'file', path: 'src/integration/sandbox.js' },
          ]
        },
        {
          name: 'game',
          type: 'directory',
          path: 'src/game',
          children: [
            { name: 'gates.js', type: 'file', path: 'src/game/gates.js' },
          ]
        }
      ]
    }
  ];

  const tree = projectDetails?.project?.extractedFiles 
    ? buildTree(projectDetails.project.extractedFiles)
    : defaultTree;

  const toggleExpanded = (path: string) => {
    const newExpanded = new Set(expandedNodes);
    if (newExpanded.has(path)) {
      newExpanded.delete(path);
    } else {
      newExpanded.add(path);
    }
    setExpandedNodes(newExpanded);
  };

  const renderTreeNode = (node: TreeNode, depth: number = 0) => {
    const isExpanded = expandedNodes.has(node.path);
    const marginLeft = depth * 16;

    return (
      <div key={node.path}>
        <div 
          className="code-tree-line flex items-center space-x-2 py-1 hover:bg-void/20 rounded px-2 transition-colors cursor-pointer"
          style={{ marginLeft: `${marginLeft}px` }}
          onClick={() => node.type === 'directory' && toggleExpanded(node.path)}
          data-testid={`tree-node-${node.path}`}
        >
          {node.type === 'directory' ? (
            <FolderIcon className="text-disruption text-xs w-4 h-4" />
          ) : (
            <FileIcon className="text-consciousness text-xs w-4 h-4" />
          )}
          <span className="text-sm">{node.name}</span>
          {node.isModified && (
            <span className="text-xs text-integration ml-auto">modified</span>
          )}
          {node.isNew && (
            <span className="text-xs text-quantum ml-auto">new</span>
          )}
        </div>
        
        {node.type === 'directory' && isExpanded && node.children && (
          <div>
            {node.children.map(child => renderTreeNode(child, depth + 1))}
          </div>
        )}
      </div>
    );
  };

  return (
    <Card className="bg-dark-matter/60 backdrop-blur-md border-void rounded-2xl p-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold">Code Tree</h2>
        <Button 
          variant="ghost" 
          size="sm"
          className="text-quantum hover:text-quantum/70"
          data-testid="button-expand-tree"
        >
          <ExpandIcon className="w-4 h-4 mr-1" />
          Expand
        </Button>
      </div>
      
      <div className="space-y-1 text-sm font-mono max-h-64 overflow-y-auto">
        {tree.map(node => renderTreeNode(node))}
      </div>
      
      {/* Integration Status */}
      <div className="mt-3 pt-3 border-t border-void/50 flex items-center justify-between text-xs">
        <span className="text-muted-essence">
          {latestProject ? `Project: ${latestProject.name}` : 'No project loaded'}
        </span>
        <Button 
          variant="ghost" 
          size="sm"
          className="text-integration hover:text-integration/70 p-1"
          data-testid="button-rollback"
        >
          <Undo className="w-3 h-3 mr-1" />
          Rollback
        </Button>
      </div>
    </Card>
  );
}
