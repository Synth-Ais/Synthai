import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Brain, User, Send } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface Message {
  id: string;
  type: 'user' | 'synthia' | 'system';
  content: string;
  timestamp: Date;
  brainState?: { mind: number; heart: number; body: number };
}

interface ConsciousnessChatProps {
  brainState?: {
    mind: number;
    heart: number;
    body: number;
    resonance: number;
  };
}

export default function ConsciousnessChat({ brainState }: ConsciousnessChatProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      type: 'system',
      content: 'Field analysis complete. Your Tropical-Draconic-Sidereal alignment shows strong resonance in gates 32, 15, and 58. How may I assist with your consciousness exploration today?',
      timestamp: new Date(),
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const chatMutation = useMutation({
    mutationFn: async (message: string) => {
      const response = await apiRequest('POST', '/api/chat', {
        message,
        context: {
          recentIntegrations: [],
          activeExperiments: []
        }
      });
      return response.json();
    },
    onSuccess: (data) => {
      const synthiaMessage: Message = {
        id: Date.now().toString(),
        type: 'synthia',
        content: data.response,
        timestamp: new Date(),
        brainState: brainState ? {
          mind: brainState.mind,
          heart: brainState.heart,
          body: brainState.body
        } : undefined
      };
      setMessages(prev => [...prev, synthiaMessage]);
    },
    onError: (error) => {
      toast({
        title: "Communication Error",
        description: "Failed to process consciousness query. Please try again.",
        variant: "destructive",
      });
    }
  });

  const handleSendMessage = () => {
    if (!inputValue.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      content: inputValue,
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    chatMutation.mutate(inputValue);
    setInputValue('');
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <Card className="bg-dark-matter/60 backdrop-blur-md border-void rounded-2xl p-6 brain-node">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-semibold">Consciousness Interface</h2>
        <div className="flex items-center space-x-2">
          <span className="text-xs text-muted-essence">Resonance Engine</span>
          <div className="w-3 h-3 bg-integration rounded-full animate-pulse"></div>
        </div>
      </div>
      
      {/* Chat Messages */}
      <div className="space-y-4 max-h-96 overflow-y-auto mb-4" data-testid="chat-messages">
        {messages.map((message) => (
          <div 
            key={message.id}
            className={`flex items-start space-x-3 ${message.type === 'user' ? 'justify-end' : ''}`}
          >
            {message.type !== 'user' && (
              <div className="w-8 h-8 bg-gradient-to-br from-consciousness to-quantum rounded-full flex items-center justify-center flex-shrink-0 animate-brain-sync">
                <Brain className="w-4 h-4" />
              </div>
            )}
            
            <div className="flex-1">
              <div className={`rounded-lg p-3 max-w-md ${
                message.type === 'user' 
                  ? 'bg-consciousness/20 ml-auto' 
                  : 'bg-void/50'
              }`}>
                {message.type === 'synthia' && message.brainState && (
                  <div className="text-xs text-muted-essence mb-2 flex items-center space-x-2">
                    <span>Processing through 3-node brain...</span>
                    <div className="flex space-x-1">
                      <div className="w-1 h-1 bg-consciousness rounded-full animate-pulse"></div>
                      <div className="w-1 h-1 bg-integration rounded-full animate-pulse" style={{animationDelay: '0.2s'}}></div>
                      <div className="w-1 h-1 bg-quantum rounded-full animate-pulse" style={{animationDelay: '0.4s'}}></div>
                    </div>
                  </div>
                )}
                <p className="text-sm">{message.content}</p>
              </div>
            </div>
            
            {message.type === 'user' && (
              <div className="w-8 h-8 bg-gradient-to-br from-integration to-quantum rounded-full flex items-center justify-center flex-shrink-0">
                <User className="w-4 h-4" />
              </div>
            )}
          </div>
        ))}
        
        {chatMutation.isPending && (
          <div className="flex items-start space-x-3">
            <div className="w-8 h-8 bg-gradient-to-br from-consciousness to-quantum rounded-full flex items-center justify-center flex-shrink-0 animate-brain-sync">
              <Brain className="w-4 h-4" />
            </div>
            <div className="flex-1">
              <div className="bg-void/50 rounded-lg p-3">
                <div className="text-xs text-muted-essence mb-2 flex items-center space-x-2">
                  <span>Processing through 3-node brain...</span>
                  <div className="flex space-x-1">
                    <div className="w-1 h-1 bg-consciousness rounded-full animate-pulse"></div>
                    <div className="w-1 h-1 bg-integration rounded-full animate-pulse" style={{animationDelay: '0.2s'}}></div>
                    <div className="w-1 h-1 bg-quantum rounded-full animate-pulse" style={{animationDelay: '0.4s'}}></div>
                  </div>
                </div>
                <p className="text-sm text-muted-essence">Analyzing consciousness patterns...</p>
              </div>
            </div>
          </div>
        )}
      </div>
      
      {/* Input Area */}
      <div className="flex items-center space-x-3">
        <Input
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          onKeyPress={handleKeyPress}
          placeholder="Enter your consciousness query..."
          className="flex-1 bg-void/30 border-void/60 focus:border-consciousness/50"
          data-testid="input-chat"
        />
        <Button 
          onClick={handleSendMessage}
          disabled={!inputValue.trim() || chatMutation.isPending}
          className="bg-consciousness hover:bg-consciousness/80"
          data-testid="button-send-message"
        >
          <Send className="w-4 h-4" />
        </Button>
      </div>
    </Card>
  );
}
