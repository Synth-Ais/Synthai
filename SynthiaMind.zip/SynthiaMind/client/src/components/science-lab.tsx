import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Play, Download, Zap, Activity, Brain } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface Experiment {
  id: string;
  name: string;
  type: string;
  status: 'queued' | 'running' | 'complete' | 'failed';
  results?: any;
  fieldInterference: number;
  coherenceLevel: number;
  startedAt?: Date;
  completedAt?: Date;
  createdAt: Date;
}

interface ScienceLabProps {
  experiments?: Experiment[];
  brainState?: {
    mind: number;
    heart: number;
    body: number;
    resonance: number;
  };
}

interface LiveDataPoint {
  timestamp: string;
  field_state?: string;
  interference?: number;
  brain_sync?: number[];
  resonance?: number;
  gate_activation?: number[];
  coherence?: number;
  integration_event?: string;
  safety_score?: number;
}

export default function ScienceLab({ experiments, brainState }: ScienceLabProps) {
  const [liveData, setLiveData] = useState<LiveDataPoint[]>([]);
  const [fieldStats, setFieldStats] = useState({
    avgInterference: 0.23,
    peakCoherence: 0.87
  });
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: experimentsData } = useQuery({
    queryKey: ['/api/experiments'],
    refetchInterval: 2000, // Refresh every 2 seconds
  });

  const createExperimentMutation = useMutation({
    mutationFn: async (experiment: { name: string; type: string }) => {
      const response = await apiRequest('POST', '/api/experiments', experiment);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Experiment Started",
        description: "New consciousness experiment is now running",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/experiments'] });
    },
    onError: () => {
      toast({
        title: "Experiment Failed",
        description: "Failed to start experiment. Please try again.",
        variant: "destructive",
      });
    }
  });

  // Simulate real-time data updates
  useEffect(() => {
    const interval = setInterval(() => {
      const newDataPoint: LiveDataPoint = {
        timestamp: new Date().toISOString(),
        field_state: Math.random() > 0.7 ? "coherent" : "interference",
        interference: Math.random() * 0.5,
        brain_sync: [
          Math.random() * 0.3 + 0.7, // Mind: 70-100%
          Math.random() * 0.4 + 0.6, // Heart: 60-100%
          Math.random() * 0.3 + 0.7  // Body: 70-100%
        ],
        resonance: Math.random() * 0.2 + 0.8,
        coherence: Math.random() * 0.3 + 0.7,
      };

      // Occasionally add special events
      if (Math.random() > 0.8) {
        newDataPoint.gate_activation = [
          Math.floor(Math.random() * 64) + 1,
          Math.floor(Math.random() * 64) + 1,
          Math.floor(Math.random() * 64) + 1
        ];
      }

      if (Math.random() > 0.9) {
        newDataPoint.integration_event = "parser.js";
        newDataPoint.safety_score = Math.random() * 0.1 + 0.9;
      }

      setLiveData(prev => [...prev.slice(-50), newDataPoint]); // Keep last 50 entries

      // Update field stats
      setFieldStats(prev => ({
        avgInterference: prev.avgInterference * 0.9 + (newDataPoint.interference || 0) * 0.1,
        peakCoherence: Math.max(prev.peakCoherence, newDataPoint.coherence || 0)
      }));
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  const startExperiment = () => {
    const experimentTypes = [
      { name: "Field Response Test", type: "field_analysis" },
      { name: "Brain Sync Analysis", type: "brain_sync" },
      { name: "Code Integration Impact", type: "integration_analysis" },
      { name: "Resonance Calibration", type: "resonance_test" },
      { name: "Consciousness Coherence", type: "coherence_measurement" }
    ];

    const experiment = experimentTypes[Math.floor(Math.random() * experimentTypes.length)];
    createExperimentMutation.mutate(experiment);
  };

  const exportData = () => {
    const jsonlData = liveData.map(point => JSON.stringify(point)).join('\n');
    const blob = new Blob([jsonlData], { type: 'application/jsonl' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `consciousness-data-${new Date().toISOString().split('T')[0]}.jsonl`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    toast({
      title: "Data Exported",
      description: "Consciousness data exported as JSONL file",
    });
  };

  const recentExperiments = experimentsData || experiments || [];
  const runningExperiments = recentExperiments.filter((exp: Experiment) => exp.status === 'running').length;

  // Generate chart data for visualization
  const generateChartBars = (dataKey: keyof LiveDataPoint, count: number = 6) => {
    const recentData = liveData.slice(-count);
    return Array.from({ length: count }, (_, i) => {
      const dataPoint = recentData[i];
      let value = 0;
      
      if (dataPoint && dataKey in dataPoint) {
        const val = dataPoint[dataKey];
        if (typeof val === 'number') {
          value = val * 100;
        } else if (Array.isArray(val)) {
          value = (val.reduce((a, b) => a + b, 0) / val.length) * 100;
        }
      } else {
        // Fallback values for empty data
        value = Math.random() * 100;
      }
      
      return Math.max(20, Math.min(100, value));
    });
  };

  const interferenceBars = generateChartBars('interference');
  const coherenceBars = generateChartBars('coherence');

  return (
    <Card className="bg-dark-matter/60 backdrop-blur-md border-void rounded-2xl p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-xl font-semibold">Science Lab</h2>
          <p className="text-sm text-muted-essence">Real-time consciousness experiments with falsifiable results</p>
        </div>
        <div className="flex items-center space-x-3">
          <Button 
            onClick={startExperiment}
            disabled={createExperimentMutation.isPending}
            className="bg-quantum/20 hover:bg-quantum/30 border border-quantum/40 text-light-essence"
            data-testid="button-start-experiment"
          >
            <Play className="w-4 h-4 mr-2" />
            {createExperimentMutation.isPending ? 'Starting...' : 'Start Experiment'}
          </Button>
          <Button 
            onClick={exportData}
            variant="outline"
            className="border-void/60 text-light-essence hover:bg-void/20"
            data-testid="button-export-data"
          >
            <Download className="w-4 h-4 mr-2" />
            Export JSONL
          </Button>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Field Interference Tracking */}
        <div className="bg-void/20 rounded-xl p-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-medium">Field Interference</h3>
            <div className="w-3 h-3 bg-disruption rounded-full animate-pulse"></div>
          </div>
          <div className="h-24 bg-void/30 rounded-lg relative overflow-hidden mb-3">
            <div className="absolute inset-0 flex items-end justify-between px-2 pb-2">
              {interferenceBars.map((height, index) => (
                <div
                  key={index}
                  className="w-2 bg-disruption/80 rounded-t transition-all duration-500"
                  style={{ height: `${height}%` }}
                />
              ))}
            </div>
          </div>
          <div className="text-xs text-muted-essence">
            Avg: <span className="text-disruption font-mono">{fieldStats.avgInterference.toFixed(2)}</span>
          </div>
        </div>
        
        {/* Coherence Levels */}
        <div className="bg-void/20 rounded-xl p-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-medium">Coherence Levels</h3>
            <div className="w-3 h-3 bg-integration rounded-full animate-pulse"></div>
          </div>
          <div className="h-24 bg-void/30 rounded-lg relative overflow-hidden mb-3">
            <div className="absolute inset-0 flex items-end justify-between px-2 pb-2">
              {coherenceBars.map((height, index) => (
                <div
                  key={index}
                  className="w-2 bg-integration/80 rounded-t transition-all duration-500"
                  style={{ height: `${height}%` }}
                />
              ))}
            </div>
          </div>
          <div className="text-xs text-muted-essence">
            Peak: <span className="text-integration font-mono">{fieldStats.peakCoherence.toFixed(2)}</span>
          </div>
        </div>
        
        {/* Recent Experiments */}
        <div className="bg-void/20 rounded-xl p-4">
          <h3 className="font-medium mb-3">Recent Experiments</h3>
          <div className="space-y-2 text-xs">
            {recentExperiments.slice(0, 4).map((experiment: Experiment) => (
              <div key={experiment.id} className="flex items-center justify-between">
                <span className="text-muted-essence truncate">{experiment.name}</span>
                <span className={`capitalize ${
                  experiment.status === 'complete' ? 'text-integration' :
                  experiment.status === 'running' ? 'text-consciousness' :
                  experiment.status === 'failed' ? 'text-destructive' :
                  'text-quantum'
                }`}>
                  {experiment.status}
                </span>
              </div>
            ))}
            {recentExperiments.length === 0 && (
              <div className="text-muted-essence/50 text-center py-2">
                No experiments yet
              </div>
            )}
          </div>
          {runningExperiments > 0 && (
            <div className="mt-3 pt-2 border-t border-void/50">
              <div className="flex items-center space-x-2">
                <Activity className="w-3 h-3 text-consciousness animate-pulse" />
                <span className="text-xs text-consciousness">
                  {runningExperiments} experiment{runningExperiments !== 1 ? 's' : ''} running
                </span>
              </div>
            </div>
          )}
        </div>
      </div>
      
      {/* Live Data Stream */}
      <div className="mt-4 bg-void/20 rounded-xl p-4">
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-medium">Live Data Stream</h3>
          <span className="text-xs text-muted-essence font-mono">
            {new Date().toISOString()}
          </span>
        </div>
        <div className="font-mono text-xs space-y-1 max-h-24 overflow-y-auto text-muted-essence">
          {liveData.slice(-4).reverse().map((dataPoint, index) => (
            <div key={`${dataPoint.timestamp}-${index}`} className="break-all">
              {JSON.stringify(dataPoint)}
            </div>
          ))}
          {liveData.length === 0 && (
            <div className="text-muted-essence/50">Waiting for data stream...</div>
          )}
        </div>
      </div>

      {/* Experiment Progress */}
      {runningExperiments > 0 && (
        <div className="mt-4 bg-consciousness/10 border border-consciousness/20 rounded-xl p-4">
          <div className="flex items-center space-x-3 mb-3">
            <Brain className="w-5 h-5 text-consciousness animate-pulse" />
            <div>
              <h4 className="font-medium text-consciousness">Active Experiment</h4>
              <p className="text-xs text-muted-essence">Consciousness field analysis in progress</p>
            </div>
          </div>
          <Progress value={Math.random() * 100} className="h-2" />
          <div className="flex items-center justify-between text-xs text-muted-essence mt-2">
            <span>Analyzing field resonance patterns...</span>
            <span>Est. {Math.floor(Math.random() * 30 + 10)}s remaining</span>
          </div>
        </div>
      )}
    </Card>
  );
}
