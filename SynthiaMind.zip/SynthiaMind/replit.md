# Overview

Synthia is a consciousness simulation platform that combines AI-powered code analysis with an interactive dashboard interface. The application serves as a self-building system that can analyze, integrate, and safely modify codebases through ZIP file uploads while maintaining backup and rollback capabilities. It features a unique "three-brain system" (Mind, Heart, Body) that represents different aspects of consciousness processing, along with gamification elements like gates and quests to guide user progression.

# User Preferences

Preferred communication style: Simple, everyday language.

# Recent Changes

## January 17, 2025
- Fixed navigation menu layout issue where tab text was overlapping
- Implemented responsive tab design with icons that work on mobile devices
- Enhanced file upload system to support multiple file types beyond ZIP files
- Added natural language processing capabilities for English instruction processing
- Created comprehensive OpenAI integration service with graceful fallback when API key unavailable

# System Architecture

## Frontend Architecture
The client-side is built with React and TypeScript, utilizing Vite as the build tool. The UI is constructed with shadcn/ui components built on top of Radix UI primitives, providing a comprehensive design system with dark theme support. The application uses Wouter for client-side routing and TanStack Query for state management and API communication.

The frontend follows a modular component structure with specialized components for:
- Code integration and visualization (drag-drop ZIP uploads, file tree displays)
- Consciousness simulation interface (three-brain status monitoring, chat interface)
- Gamification elements (gates system, quests, experiments)
- Real-time data visualization (science lab with live metrics)

## Backend Architecture
The server runs on Express.js with TypeScript, implementing a REST API architecture. The backend uses a storage abstraction layer that supports both database operations and in-memory storage for development. The server includes comprehensive middleware for logging, error handling, and file upload processing via Multer.

Key backend services include:
- **ZIP Extractor Service**: Processes uploaded ZIP files and extracts code content safely
- **Code Analysis Service**: Uses Babel parser for JavaScript/TypeScript AST analysis and function extraction
- **OpenAI Integration Service**: Provides AI-powered code analysis, compatibility scoring, and integration recommendations
- **Sandbox Runner Service**: Executes code safely in isolated VM environments using vm2

## Data Storage Solutions
The application uses Drizzle ORM with PostgreSQL as the primary database, configured through Neon Database serverless connection. The schema supports:
- User management and authentication
- Code project storage with ZIP data and extracted files
- Code analysis results with AST data and function signatures  
- Integration history with rollback capabilities
- Brain state tracking for consciousness simulation
- Experiments and gamification progress

Database migrations are handled through Drizzle Kit with schema definitions in shared TypeScript files.

## Authentication and Authorization
The system implements a basic user authentication system with username/password credentials. Authentication state is managed through HTTP sessions with credential-based API requests.

## External Service Integrations
- **OpenAI API**: Powers the AI code analysis, providing compatibility scoring, integration recommendations, and conversational chat interface
- **Google Cloud Storage**: Handles file storage and backup operations for code projects
- **Uppy File Upload**: Provides drag-and-drop file upload interface with AWS S3 support
- **Neon Database**: Serverless PostgreSQL hosting for production data persistence

The architecture emphasizes safety through sandboxed code execution, comprehensive backup systems, and gradual integration workflows with rollback capabilities. The consciousness simulation aspect adds a unique gamified layer that encourages safe experimentation and learning through the three-brain system metaphor.