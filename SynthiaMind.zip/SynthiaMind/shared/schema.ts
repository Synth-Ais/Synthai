import { sql } from "drizzle-orm";
import { pgTable, text, varchar, jsonb, timestamp, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const codeProjects = pgTable("code_projects", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description"),
  zipData: text("zip_data"), // base64 encoded zip
  extractedFiles: jsonb("extracted_files").$type<Record<string, string>>(),
  createdAt: timestamp("created_at").defaultNow(),
  userId: varchar("user_id").references(() => users.id),
});

export const codeAnalysis = pgTable("code_analysis", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").references(() => codeProjects.id),
  fileName: text("file_name").notNull(),
  fileType: text("file_type").notNull(),
  astData: jsonb("ast_data"),
  functions: jsonb("functions").$type<Array<{
    name: string;
    params: string[];
    returnType?: string;
    complexity: number;
    dependencies: string[];
  }>>(),
  imports: jsonb("imports").$type<string[]>(),
  exports: jsonb("exports").$type<string[]>(),
  compatibility: integer("compatibility").default(0), // 0-100 score
  createdAt: timestamp("created_at").defaultNow(),
});

export const integrationHistory = pgTable("integration_history", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").references(() => codeProjects.id),
  integratedFiles: jsonb("integrated_files").$type<string[]>(),
  changes: jsonb("changes").$type<Array<{
    type: 'add' | 'modify' | 'delete';
    file: string;
    content: string;
  }>>(),
  rollbackData: jsonb("rollback_data"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const brainStates = pgTable("brain_states", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  mind: integer("mind").default(0), // 0-100
  heart: integer("heart").default(0), // 0-100
  body: integer("body").default(0), // 0-100
  resonance: integer("resonance").default(0), // 0-100
  timestamp: timestamp("timestamp").defaultNow(),
});

export const experiments = pgTable("experiments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  type: text("type").notNull(),
  status: text("status").default('queued'), // queued, running, complete, failed
  results: jsonb("results"),
  fieldInterference: integer("field_interference").default(0),
  coherenceLevel: integer("coherence_level").default(0),
  startedAt: timestamp("started_at"),
  completedAt: timestamp("completed_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const gates = pgTable("gates", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  gateNumber: integer("gate_number").notNull().unique(),
  isUnlocked: boolean("is_unlocked").default(false),
  unlockedAt: timestamp("unlocked_at"),
  layer: integer("layer").default(1), // 1, 2, or 3
});

export const quests = pgTable("quests", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  description: text("description").notNull(),
  type: text("type").notNull(), // integration, analysis, experiment
  targetCount: integer("target_count").default(1),
  currentProgress: integer("current_progress").default(0),
  isCompleted: boolean("is_completed").default(false),
  reward: text("reward"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertCodeProjectSchema = createInsertSchema(codeProjects).omit({
  id: true,
  createdAt: true,
});

export const insertCodeAnalysisSchema = createInsertSchema(codeAnalysis).omit({
  id: true,
  createdAt: true,
});

export const insertIntegrationHistorySchema = createInsertSchema(integrationHistory).omit({
  id: true,
  createdAt: true,
});

export const insertBrainStateSchema = createInsertSchema(brainStates).omit({
  id: true,
  timestamp: true,
});

export const insertExperimentSchema = createInsertSchema(experiments).omit({
  id: true,
  createdAt: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type CodeProject = typeof codeProjects.$inferSelect;
export type InsertCodeProject = z.infer<typeof insertCodeProjectSchema>;

export type CodeAnalysis = typeof codeAnalysis.$inferSelect;
export type InsertCodeAnalysis = z.infer<typeof insertCodeAnalysisSchema>;

export type IntegrationHistory = typeof integrationHistory.$inferSelect;
export type InsertIntegrationHistory = z.infer<typeof insertIntegrationHistorySchema>;

export type BrainState = typeof brainStates.$inferSelect;
export type InsertBrainState = z.infer<typeof insertBrainStateSchema>;

export type Experiment = typeof experiments.$inferSelect;
export type InsertExperiment = z.infer<typeof insertExperimentSchema>;

export type Gate = typeof gates.$inferSelect;
export type Quest = typeof quests.$inferSelect;
