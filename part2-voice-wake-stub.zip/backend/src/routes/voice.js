const express = require('express');
const router = express.Router();

// Expect app.locals models & emitter injected from server.js setup
router.post('/note', async (req,res)=>{
  try{
    const { Qualia, thoughtEmitter } = req.app.locals;
    const { text, channel='action', spoken=true, action='speech', node } = req.body || {};
    const doc = await Qualia.create({
      node: node || 'Body',
      channel, text, spoken, action,
      meta: { source:'voice', ...(req.body && req.body.meta || {}) },
      confidence: typeof req.body?.confidence === 'number' ? req.body.confidence : 1.0
    });
    thoughtEmitter.emit('newThought', doc);
    res.status(201).json(doc);
  }catch(e){
    res.status(500).json({ error: e.message });
  }
});

module.exports = router;
