const express = require('express');
const router = express.Router();

router.post('/ping', async (req,res)=>{
  try{
    const { Qualia, thoughtEmitter } = req.app.locals;
    const doc = await Qualia.create({
      node:'Body', channel:'action', text:'(wake)', spoken:true, action:'wake', meta:{ source:'wake' }
    });
    thoughtEmitter.emit('newThought', doc);
    res.json({ ok:true });
  }catch(e){
    res.status(500).json({ error:e.message });
  }
});

module.exports = router;
