# Cynthia v0.1 — Part 2: Voice, Wake‑Word & Coach Stub

This pack gives Cynthia a *voice*, a browser‑level *wake word* (“hey cynthia”), and a *Life Coach* panel that logs thoughts to your existing backend.

## What’s inside
- `frontend/src/components/VoicePanel.jsx` — UI to start/stop mic, detect wake word via Web Speech API, and speak back via speechSynthesis.
- `frontend/src/lib/tts.js` — Tiny TTS wrapper (browser speechSynthesis).
- `frontend/src/lib/wake.js` — Wake word listener using SpeechRecognition; keyword match on interim transcripts.
- `frontend/src/api/voiceApi.js` — REST helpers to send transcripts/wake pings to backend.
- `backend/src/routes/voice.js` — New endpoints `/voice/note` and `/wake/ping` to log voice events as Qualia and broadcast over SSE.
- `backend/.env.example` — Adds `WAKE_WORD=hey cynthia`.

## How to integrate
1) Drop `frontend/*` files into your repo’s `frontend/` and import `VoicePanel` somewhere (e.g., navbar or `/qualia` page).  
2) Drop `backend/src/routes/voice.js` into `backend/src/routes/` and add this to your `server.js`:
```js
const voiceRoutes = require('./src/routes/voice'); // adjust path if needed
app.use('/voice', voiceRoutes);
```
3) Add `WAKE_WORD=hey cynthia` to `backend/.env` (optional, defaults to “hey cynthia”).  
4) Restart backend and frontend.

## Usage
- Click **Wake Listener → Start** in the UI. Say “hey cynthia …” and keep talking.
- The wake event POSTs to `/wake/ping`; transcript POSTs to `/voice/note` with `spoken:true`.
- Everything appears live on `/qualia` because we reuse the existing Qualia model & SSE.

## Notes / Limits
- Web Speech API varies by browser; Chrome works best. Mobile Safari may require a tap to start.
- This is a privacy‑first *press‑to‑listen* model (no always‑on background). You can flip to auto‑restart in `wake.js` if you accept continuous listening.
- For server‑side TTS or STT, plug in vendors (ElevenLabs, Deepgram, Vosk) later. This stub keeps v0.1 dependency‑free.
