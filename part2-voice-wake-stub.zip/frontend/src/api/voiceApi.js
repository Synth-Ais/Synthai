import axios from 'axios';
const API = '/api';

export const postWakePing = () => axios.post(`${API}/wake/ping`, { ts: Date.now() });
export const postVoiceNote = (payload) => axios.post(`${API}/voice/note`, payload);
