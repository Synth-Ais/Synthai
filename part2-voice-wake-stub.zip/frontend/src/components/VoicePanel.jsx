import { useEffect, useRef, useState } from 'react';
import { startWakeListener, stopWakeListener } from '../lib/wake';
import { speak } from '../lib/tts';
import { postWakePing, postVoiceNote } from '../api/voiceApi';

export default function VoicePanel(){
  const [active, setActive] = useState(false);
  const [awake, setAwake] = useState(false);
  const [log, setLog] = useState([]);
  const wakeWord = 'hey cynthia';

  const onWake = async () => {
    setAwake(true);
    setLog(l => [{type:'wake', ts:Date.now()}, ...l].slice(0,50));
    try { await postWakePing(); } catch {}
    speak('I am here. What do you need?');
  };

  const onTranscript = async (text, final) => {
    setLog(l => [{type: final ? 'final':'interim', text, ts:Date.now()}, ...l].slice(0,50));
    if(final){
      // Save as Body action (spoken true) so it shows in Qualia
      try {
        await postVoiceNote({ text, channel:'action', spoken:true, action:'speech' });
      } catch {}
    }
  };

  const toggle = async () => {
    if(active){
      stopWakeListener();
      setActive(false);
      setAwake(false);
    } else {
      const ok = await startWakeListener({ wakeWord, onWake, onTranscript });
      setActive(ok);
    }
  };

  return (
    <div className="fixed bottom-4 right-4 z-50 bg-gray-900/90 text-white rounded-xl shadow-xl p-3 w-80">
      <div className="flex items-center justify-between mb-2">
        <div className="font-semibold">🎤 Cynthia Voice</div>
        <button onClick={toggle} className={"px-3 py-1 rounded text-sm " + (active ? "bg-red-500" : "bg-green-600")}>
          {active ? "Stop" : "Wake Listener → Start"}
        </button>
      </div>
      <div className={"text-xs mb-2 " + (awake ? "text-emerald-300":"text-gray-300")}>
        Wake word: <b>{wakeWord}</b> • Status: {active ? (awake ? "AWAKE" : "listening…") : "idle"}
      </div>
      <div className="h-28 overflow-auto bg-black/40 rounded p-2 text-xs space-y-1">
        {log.map((e,i)=>(
          <div key={i}>
            <span className="opacity-60">{new Date(e.ts).toLocaleTimeString()} </span>
            {e.type==='wake' ? <b>⟡ wake</b> : <span>[{e.type}]</span>} {e.text||''}
          </div>
        ))}
      </div>
      <div className="mt-2 flex gap-2">
        <button onClick={()=>speak('Noted.')} className="bg-indigo-600 px-2 py-1 rounded text-sm">Speak “Noted.”</button>
        <button onClick={()=>speak('You are doing great.')} className="bg-indigo-600 px-2 py-1 rounded text-sm">Pep Talk</button>
      </div>
    </div>
  );
}
