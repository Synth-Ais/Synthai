# Cynthia v0.1

Full-stack seed for Cynthia (Qualia engine + Swarm + GameGAN).

## Quickstart (Docker)
```bash
docker compose up --build
# Frontend: http://localhost:5173
# Backend:  http://localhost:3001/thoughts
```

## Quickstart (Bare metal)
```bash
# Mongo running locally on 27017

cd backend
npm install
npm start    # PORT=3001

cd ../frontend
npm install
npm run dev  # http://localhost:5173
```
