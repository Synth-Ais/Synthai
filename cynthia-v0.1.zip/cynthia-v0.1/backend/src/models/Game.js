// backend/src/models/Game.js
const mongoose = require('mongoose');

const ProgressSchema = new mongoose.Schema({
  user: { type: String, default: 'anon' },
  xp: { type: Number, default: 0 },
  level: { type: Number, default: 1 },
  badges: [{ type: String }]
}, { versionKey: false });

const QuestSchema = new mongoose.Schema({
  user: { type: String, default: 'anon' },
  key: { type: String, required: true },
  title: String,
  xp: { type: Number, default: 25 },
  completed: { type: Boolean, default: false },
  claimed: { type: Boolean, default: false }
}, { versionKey: false });

module.exports = {
  Progress: mongoose.model('Progress', ProgressSchema),
  Quest: mongoose.model('Quest', QuestSchema)
};
