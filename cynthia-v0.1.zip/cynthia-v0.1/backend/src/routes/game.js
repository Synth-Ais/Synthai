// backend/src/routes/game.js
const express = require('express');
const router = express.Router();
const { Progress, Quest } = require('../models/Game');

function addXp(p, amt){
  p.xp += amt;
  while (p.xp >= 100) { p.xp -= 100; p.level += 1; }
}

router.get('/progress', async (req,res) => {
  const user = req.query.user || 'anon';
  const p = await Progress.findOne({ user }) || await Progress.create({ user });
  const qs = await Quest.find({ user }).sort({ key: 1 });
  res.json({ user, xp: p.xp, level: p.level, badges: p.badges, quests: qs });
});

router.post('/seed', async (req,res) => {
  const user = req.body.user || 'anon';
  const seeds = [
    { key:'first-impulse', title:'Log a Heart impulse', xp:20 },
    { key:'first-thought', title:'Record a Mind thought', xp:25 },
    { key:'first-action', title:'Trigger a Body action', xp:30 },
    { key:'gate-16', title:'Complete Gate 16 (any field)', xp:50 }
  ];
  await Quest.deleteMany({ user });
  await Quest.insertMany(seeds.map(s => ({ ...s, user })));
  res.json({ ok:true, seeded: seeds.length });
});

router.post('/event', async (req,res) => {
  const user = req.body.user || 'anon';
  const { type, channel, field, gate } = req.body;
  const p = await Progress.findOne({ user }) || await Progress.create({ user });

  let xp=0; let badge=null;
  if (type === 'thought') {
    xp = channel==='impulse' ? 5 : channel==='thought' ? 8 : channel==='action' ? 12 : 0;
    if (channel==='action') badge = 'Action Taker';
  }
  if (type === 'gateComplete') {
    xp = 25;
    if (Number(gate) === 16) xp += 10;
  }

  addXp(p, xp);
  if (badge && !p.badges.includes(badge)) p.badges.push(badge);
  await p.save();

  // auto-complete some quests
  if (channel==='impulse') await Quest.updateOne({ user, key:'first-impulse' }, { completed:true });
  if (channel==='thought') await Quest.updateOne({ user, key:'first-thought' }, { completed:true });
  if (channel==='action') await Quest.updateOne({ user, key:'first-action' }, { completed:true });
  if (type==='gateComplete' && Number(gate)===16) await Quest.updateOne({ user, key:'gate-16' }, { completed:true });

  res.json({ ok:true, gained: xp });
});

router.post('/claim', async (req,res) => {
  const user = req.body.user || 'anon';
  const key = req.body.key;
  const q = await Quest.findOne({ user, key });
  if (!q) return res.status(404).json({ error: 'quest not found' });
  if (!q.completed || q.claimed) return res.json({ ok:false, reason:'not ready' });

  const p = await Progress.findOne({ user }) || await Progress.create({ user });
  addXp(p, q.xp);
  await p.save();
  q.claimed = true; await q.save();

  res.json({ ok:true, claimed:key, xp:q.xp });
});

module.exports = router;
