// backend/server.js
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const http = require('http');
const { EventEmitter } = require('events');

const app = express();
const server = http.createServer(app);
const port = process.env.PORT || 3001;

app.use(cors());
app.use(express.json({ limit: '256kb' }));

// Mongo connection
const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/cynthia';
mongoose.connect(MONGO_URI).then(() => console.log('Mongo connected')).catch(err => {
  console.error('Mongo error:', err.message);
  process.exit(1);
});

// Event bus for SSE
const thoughtEmitter = new EventEmitter();

// Models
const Qualia = mongoose.model('Qualia', new mongoose.Schema({
  node: { type: String, enum: ['Heart','Mind','Body'], required: true },
  channel: { type: String, enum: ['impulse','thought','action'], required: true },
  text: { type: String, required: true },
  spoken: { type: Boolean, default: false },
  action: { type: String },
  meta: { type: Object },
  confidence: { type: Number, default: 1.0 },
  createdAt: { type: Date, default: Date.now },
}, { versionKey: false }));

const SwarmProgress = mongoose.model('SwarmProgress', new mongoose.Schema({
  field: { type: String, enum: ['Body','Heart','Mind'], required: true },
  gate: { type: Number, required: true },
  completed: { type: Boolean, default: false },
  progress: { type: Number, default: 0 },
  active: { type: Boolean, default: false },
  updatedAt: { type: Date, default: Date.now },
}, { versionKey: false }));

// Routes: thoughts
app.get('/thoughts', async (req,res) => {
  const q = await Qualia.find().sort({ createdAt: -1 }).limit(200);
  res.json(q);
});

app.post('/thoughts/impulse', async (req,res) => {
  const t = await Qualia.create({ ...req.body, node:'Heart', channel:'impulse' });
  thoughtEmitter.emit('newThought', t);
  res.status(201).json(t);
});

app.post('/thoughts/thought', async (req,res) => {
  const t = await Qualia.create({ ...req.body, node:'Mind', channel:'thought', spoken:false });
  thoughtEmitter.emit('newThought', t);
  res.status(201).json(t);
});

app.post('/thoughts/action', async (req,res) => {
  const t = await Qualia.create({ ...req.body, node:'Body', channel:'action', spoken:true });
  thoughtEmitter.emit('newThought', t);
  res.status(201).json(t);
});

// SSE
app.get('/thoughts/stream', (req,res) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.write('event: hello\n');
  res.write('data: {"ok":true}\n\n');
  const onThought = (t) => res.write(`data: ${JSON.stringify(t)}\n\n`);
  thoughtEmitter.on('newThought', onThought);
  req.on('close', () => thoughtEmitter.removeListener('newThought', onThought));
});

// Swarm minimal mapping/progress
app.get('/mapping.json', (req,res) => {
  res.json({ fields: ['Body','Heart','Mind'], gates: Array.from({length:64}, (_,i)=>i+1) });
});

app.get('/progress', async (req,res) => {
  const docs = await SwarmProgress.find();
  res.json(docs);
});

app.post('/complete', async (req,res) => {
  const { field, gate } = req.body;
  const d = await SwarmProgress.findOneAndUpdate(
    { field, gate },
    { completed:true, progress:100, active:false, updatedAt:new Date() },
    { upsert:true, new:true }
  );
  res.json(d);
});

app.post('/active', async (req,res) => {
  const { field, gate } = req.body;
  const prev = await SwarmProgress.findOne({ field, gate });
  const prog = Math.max(50, prev?.progress || 0);
  const d = await SwarmProgress.findOneAndUpdate(
    { field, gate },
    { active:true, progress:prog, updatedAt:new Date() },
    { upsert:true, new:true }
  );
  res.json(d);
});

// GameGAN routes
app.use('/game', require('./src/routes/game'));

// Demo stream
if (process.env.QUALIA_DEMO === '1') {
  const nodes = ['Heart','Mind','Body'];
  const chans = ['impulse','thought','action'];
  setInterval(async () => {
    const node = nodes[Math.floor(Math.random()*3)];
    const channel = chans[Math.floor(Math.random()*3)];
    const t = await Qualia.create({
      node, channel,
      text: `demo ${channel} from ${node}`,
      spoken: channel==='action',
      meta: { demo:true }, confidence: Math.random()
    });
    thoughtEmitter.emit('newThought', t);
  }, 9000);
}

server.listen(port, () => console.log(`Backend on :${port}`));
