# ARCHITECTURE.md (concise)

- **Nodes**: Heart (impulse), Mind (thought), Body (action)
- **Backend**: Express + MongoDB, REST + SSE
- **Frontend**: React (Vite) + Tailwind
- **GameGAN**: XP/levels/quests module
- **Swarm**: 64×3 gates progress

### Key Endpoints
- GET /thoughts
- POST /thoughts/impulse | /thoughts/thought | /thoughts/action
- GET /thoughts/stream (SSE)
- GET /mapping.json
- GET /progress
- POST /complete
- POST /active
- /game: GET /progress, POST /seed, POST /event, POST /claim
