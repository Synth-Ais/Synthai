import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import Qualia from './routes/Qualia.jsx';
import Swarm from './routes/Swarm.jsx';
import GameHub from './routes/GameHub.jsx';

export default function App(){
  return (
    <Router>
      <nav style={{padding:'12px',background:'#0b0b12',color:'#fff'}}>
        <b>Cynthia v0.1</b>
        <span style={{marginLeft:12}}><Link to="/qualia">Qualia</Link></span>
        <span style={{marginLeft:12}}><Link to="/swarm">Swarm</Link></span>
        <span style={{marginLeft:12}}><Link to="/game">Game</Link></span>
      </nav>
      <Routes>
        <Route path="/" element={<Qualia/>} />
        <Route path="/qualia" element={<Qualia/>} />
        <Route path="/swarm" element={<Swarm/>} />
        <Route path="/game" element={<GameHub/>} />
      </Routes>
    </Router>
  );
}
