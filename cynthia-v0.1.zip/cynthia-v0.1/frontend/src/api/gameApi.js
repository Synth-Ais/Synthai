import axios from 'axios';
const API = '/api';
export const gameProgress = (user='anon') => axios.get(`${API}/game/progress?user=${encodeURIComponent(user)}`);
export const gameSeed = (user='anon') => axios.post(`${API}/game/seed`, { user });
export const trackEvent = (payload) => axios.post(`${API}/game/event`, payload);
export const claimQuest = (key, user='anon') => axios.post(`${API}/game/claim`, { key, user });
