import axios from 'axios';
const API = '/api';
export const getMapping = () => axios.get(`${API}/mapping.json`);
export const getProgress = () => axios.get(`${API}/progress`);
export const markComplete = (field, gate) => axios.post(`${API}/complete`, { field, gate });
export const markActive   = (field, gate) => axios.post(`${API}/active`, { field, gate });
