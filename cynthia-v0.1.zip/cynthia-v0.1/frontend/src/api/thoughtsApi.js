import axios from 'axios';
const API = '/api';
export const streamThoughts = () => new EventSource(`${API}/thoughts/stream`);
export const postImpulse = (payload) => axios.post(`${API}/thoughts/impulse`, payload);
export const postThought  = (payload) => axios.post(`${API}/thoughts/thought`, payload);
export const postAction   = (payload) => axios.post(`${API}/thoughts/action`, payload);
