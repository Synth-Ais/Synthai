import { useEffect, useState } from 'react';
import { streamThoughts, postImpulse, postThought, postAction } from '../api/thoughtsApi';

export default function Qualia(){
  const [list, setList] = useState([]);
  const [text, setText] = useState('');
  const [mode, setMode] = useState('impulse'); // impulse|thought|action

  useEffect(() => {
    const sse = streamThoughts();
    sse.onmessage = (e) => { try {
      const obj = JSON.parse(e.data);
      setList(prev => [obj, ...prev].slice(0, 100));
    } catch {} };
    return () => sse.close();
  }, []);

  async function submit(e){
    e.preventDefault();
    const payload = { text, meta: { source:'ui' } };
    if (mode==='impulse') await postImpulse(payload);
    if (mode==='thought') await postThought(payload);
    if (mode==='action') await postAction(payload);
    setText('');
  }

  return (
    <div style={{padding:16}}>
      <h2>Qualia Console</h2>
      <form onSubmit={submit} style={{marginBottom:12}}>
        <select value={mode} onChange={e=>setMode(e.target.value)}>
          <option value="impulse">Heart impulse</option>
          <option value="thought">Mind thought</option>
          <option value="action">Body action</option>
        </select>
        <input value={text} onChange={e=>setText(e.target.value)} placeholder="enter text" style={{marginLeft:8}}/>
        <button type="submit" style={{marginLeft:8}}>Send</button>
      </form>
      <div>
        {list.map((t,i)=> (
          <div key={i} style={{border:'1px solid #ddd', padding:8, marginBottom:6}}>
            <b>{t.node}/{t.channel}</b>: {t.text} {t.spoken ? '🗣️' : ''}
          </div>
        ))}
      </div>
    </div>
  );
}
