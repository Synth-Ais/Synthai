import { useEffect, useState } from 'react';
import { gameProgress, gameSeed, trackEvent, claimQuest } from '../api/gameApi';
import { postImpulse, postThought, postAction } from '../api/thoughtsApi';

export default function GameHub(){
  const [data, setData] = useState({ xp:0, level:1, badges:[], quests:[] });

  async function refresh(){ const res = await gameProgress('anon'); setData(res.data); }
  useEffect(()=>{ refresh(); }, []);

  const seed = async ()=>{ await gameSeed('anon'); await refresh(); };
  const send = async (type)=>{
    const text = `${type} demo`;
    if (type==='impulse') await postImpulse({ text });
    if (type==='thought') await postThought({ text });
    if (type==='action') await postAction({ text });
    await trackEvent({ user:'anon', type:'thought', channel: type==='impulse'?'impulse': type==='thought'?'thought':'action' });
    await refresh();
  };
  const claim = async (k)=>{ await claimQuest(k,'anon'); await refresh(); };

  const pct = (data.xp/100)*100;

  return (
    <div style={{padding:16}}>
      <h2>Game Hub</h2>
      <div style={{margin:'8px 0'}}>Level <b>{data.level}</b> — XP {data.xp}/100</div>
      <div style={{background:'#e2e8f0', height:8, borderRadius:6, overflow:'hidden', maxWidth:320}}>
        <div style={{width:`${pct}%`, height:'100%', background:'#805ad5'}}/>
      </div>
      <div style={{marginTop:12}}>
        <button onClick={seed}>Seed Quests</button>
        <button onClick={()=>send('impulse')} style={{marginLeft:8}}>Heart impulse</button>
        <button onClick={()=>send('thought')} style={{marginLeft:8}}>Mind thought</button>
        <button onClick={()=>send('action')} style={{marginLeft:8}}>Body action</button>
      </div>

      <h3 style={{marginTop:16}}>Quests</h3>
      <ul>
        {data.quests?.map(q => (
          <li key={q.key} style={{marginBottom:6}}>
            {q.title} — {q.completed ? (q.claimed?'claimed':'completed') : 'open'} (+{q.xp}xp)
            {q.completed && !q.claimed && <button onClick={()=>claim(q.key)} style={{marginLeft:8}}>Claim</button>}
          </li>
        ))}
      </ul>

      <h3>Badges</h3>
      <div>{(data.badges||[]).join(', ') || '—'}</div>
    </div>
  );
}
