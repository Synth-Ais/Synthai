import { useEffect, useState } from 'react';
import { getMapping, getProgress, markComplete } from '../api/swarmApi';
import { trackEvent } from '../api/gameApi';

export default function Swarm(){
  const [map, setMap] = useState({ fields: [], gates: [] });
  const [progress, setProgress] = useState([]);
  const fields = ['Body','Heart','Mind'];
  const [activeField, setActiveField] = useState('Body');

  async function refresh(){
    const m = await getMapping(); setMap(m.data);
    const p = await getProgress(); setProgress(p.data);
  }
  useEffect(() => { refresh(); }, []);

  function isDone(field, gate){
    return progress.some(p => p.field===field && p.gate===gate && p.completed);
  }

  async function complete(field, gate){
    await markComplete(field, gate);
    await trackEvent({ user:'anon', type:'gateComplete', field, gate });
    await refresh();
  }

  return (
    <div style={{padding:16}}>
      <h2>Swarm</h2>
      <label>Field: </label>
      <select value={activeField} onChange={e=>setActiveField(e.target.value)}>
        {fields.map(f => <option key={f} value={f}>{f}</option>)}
      </select>
      <div style={{display:'grid', gridTemplateColumns:'repeat(8,1fr)', gap:6, marginTop:12}}>
        {map.gates.map(g => (
          <button key={g}
            onClick={()=>complete(activeField, g)}
            disabled={isDone(activeField, g)}
            style={{padding:8, border:'1px solid #ccc', background: isDone(activeField, g)?'#c6f6d5':'#edf2f7'}}>
            {activeField}/{g} {isDone(activeField, g)?'✓':''}
          </button>
        ))}
      </div>
    </div>
  );
}
