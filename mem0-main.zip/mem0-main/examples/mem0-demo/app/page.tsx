import { Assistant } from "@/app/assistant"

export default function Page() {
  return <Assistant />
}