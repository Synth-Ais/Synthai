import Home from "./page"


function App() {

  return (
    <>
      <Home />
    </>
  )
}

export default App
