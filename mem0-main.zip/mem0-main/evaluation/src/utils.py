TECHNIQUES = ["mem0", "rag", "langmem", "zep", "openai"]

METHODS = ["add", "search"]
