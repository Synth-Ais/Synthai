### Streamlit Chat bot App (Embedchain + Mistral)

To run it locally,

```bash
streamlit run app.py
```
