## Chainlit + Embedchain Demo

In this example, we will learn how to use Chainlit and Embedchain together 

## Setup

First, install the required packages:

```bash
pip install -r requirements.txt
```

## Run the app locally,

```
chainlit run app.py
```
