============
 Changelog
============



v1.0.0
------

- Add tutorial


v0.5.1
------

- Improve documentation


v0.5.0
------

- Initial release of samecode
