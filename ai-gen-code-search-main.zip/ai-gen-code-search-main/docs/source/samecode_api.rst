.. _samecode_api:

SameCode library API
=================================

This section is a describes the API of SameCode classes and functions.

.. automodule:: samecode.chunking
   :members:
   :undoc-members:


.. automodule:: samecode.halohash
   :members:
   :undoc-members:


